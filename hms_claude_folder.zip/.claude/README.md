# HMS agent pack

```
.claude/
├── instructions.md   global rules R/A/C (always loaded via CLAUDE.md)
├── CLAUDE.md         one line: @instructions.md
├── settings.json     registers hooks + deny rules (Claude Code)
├── agents/           *.agent.md  (max 20 lines each)
├── prompts/          *.prompt.md (one per agent)
├── skills/<name>/SKILL.md
├── hooks/            python scripts (cross-platform)
├── specs/            BRD sliced per module (+ _core.md)
└── logs/             JSONL per day, git-ignored, kept 7 days
```

## Claude Code (personal laptop)
1. Unzip so `.claude/` sits in the project root.
2. Use an agent: "use the backend_developer agent for module appointments".
3. Run a prompt: `@.claude/prompts/build_backend.prompt.md module=appointments`.
4. Git safety net: `python .claude/hooks/pre_commit.py --install`.

## VS Code Copilot (company laptop)
1. Unzip `.github/` into the project root (generated from this folder).
2. Pick the agent in Copilot Chat; run prompts with `/build_backend`.
3. Copilot hooks are version-dependent: use the git hook (`python .github/hooks/pre_commit.py --install`).
4. Check the `tools:` and `model:` lines in `.github/agents/*` match what your Copilot version shows.
5. After editing anything in `.claude/`, regenerate: `python .claude/hooks/sync_github.py`.

## Checks
`python .claude/hooks/validate_config.py` verifies agent size/keys, prompt size and that every R/A/C ID exists.

## Token habits
New chat per module · attach only the module spec · replies = paths + 5 lines · review diffs only · cheap model for boilerplate/tests.
