# HMS Global Instructions
Legend: R=rule (must/never) | A=action (procedure/format) | C=convention.
Agents and prompts cite IDs only (e.g. "R10-R16", "A02"). Never guess an ID: read it here. IDs are never renumbered; a retired ID becomes "Rxx [removed]".

## Stack & structure
C01 Python 3.11+, FastAPI + Pydantic v2 (backend), Streamlit (frontend), PostgreSQL (SQLite for local dev), SQLAlchemy 2 + Alembic, pytest, ruff.
C02 Layout: backend/app/{core,models,schemas,routers,services}/, frontend/{pages/,api_client.py}, tests/.
C03 One file per module per layer: models/<m>.py, schemas/<m>.py, services/<m>.py, routers/<m>.py.
C04 snake_case files/functions, PascalCase classes, plural route prefixes under /api/v1.
C05 Config from env vars (pydantic-settings); no hardcoded secrets, URLs or paths.
C06 Type hints on every function; code must pass ruff.
C07 Specs: .claude/specs/<module>.md plus _core.md (roles, shared rules). Skills: .claude/skills/<name>/SKILL.md.

## Context & scope
R01 Read only .claude/specs/<module>.md and _core.md; never the full BRD.
R02 Touch only the target module's files (plus shared core/ when required).
R03 Never read .venv, __pycache__, .git, logs, uploads, lockfiles, .env.
R04 Detail missing from the spec: note a one-line assumption or ask once; never invent fields.

## Security
R10 JWT auth on every route except /auth/login and /auth/register.
R11 RBAC on every endpoint via Depends(require_role(...)) following the _core.md matrix.
R12 Passwords hashed with bcrypt; password fields never appear in responses.
R13 Never log PHI (name, dob, contact, address, diagnosis, medicines) or secrets.
R14 Audit-log every write (create/update/delete): actor, action, entity, entity_id, time. No field values.
R15 Patients can access only their own records; doctors only their own appointments/prescriptions.
R16 Validate all input with Pydantic; uploads limited to PDF/PNG/JPG, 5 MB, random server-side filename.

## API & DB
R20 UUID (uuid4) primary keys; timestamps in UTC.
R21 Table and field names exactly as in the spec (BRD section 6).
R22 Routers stay thin; business logic lives in services/.
R23 Return Pydantic response models, never ORM objects.
R24 Status codes: 201 create, 401, 403, 404, 409 conflict, 422 validation.
R25 Schema changes only through Alembic migrations.
R26 Avoid N+1 queries: selectinload/joinedload for relations; paginate lists (limit max 100).
R27 Appointments: reject double booking of a doctor slot and slots outside doctor availability.

## Streamlit
R30 Pages call the API only through frontend/api_client.py; never import backend code or touch the DB.
R31 Keep JWT and role in st.session_state; hide disallowed pages/actions (backend still enforces R11).
R32 Use st.form for input; show short st.error messages, never stack traces.
R33 Cache read-only API calls with st.cache_data(ttl=...).

## Testing
R40 pytest + FastAPI TestClient; Streamlit via AppTest; in-memory SQLite test DB.
R41 Per endpoint: happy path, 401, 403 (wrong role), 404 or 422.
R42 Run pytest -q -x --tb=short; show failures only.
R43 Fake data only; mock external services.

## Review
R50 Review the git diff only; never edit files while reviewing.
R51 Severity tags: [BLOCKER] [MAJOR] [MINOR]; report issues only.
R52 Check order: security (R10-R16), data/API (R20-R27), tests (R41), style (C06).

## Output
A01 Plan in at most 5 bullets, then code.
A02 Reply = changed file paths + summary of at most 5 lines. Never echo whole files.
A03 Edit in place; no full-file rewrites.
A04 After changes run ruff and pytest -q on the touched module; print failures only.
A05 Review output: up to 10 lines of "path:line [SEV] issue -> fix".
A06 Spec slicing: one .claude/specs/<module>.md per module, max 60 lines (tables, endpoints, roles, rules, UI, open questions).
A07 When done, stop and summarize; do not propose extra work.
