---
name: streamlit-page
description: Streamlit page, API client and role-guard pattern for HMS. Use when building or editing frontend pages.
---
# Streamlit page pattern
```python
# frontend/api_client.py
def call(method, path, **kw):
    h = {"Authorization": f"Bearer {st.session_state.get('token', '')}"}
    r = httpx.request(method, f"{API_URL}/api/v1{path}", headers=h, timeout=10, **kw)
    if r.status_code >= 400: raise ApiError(r.json().get("detail", "Request failed"))
    return r.json() if r.content else None

@st.cache_data(ttl=30)
def list_departments(token): return call("GET", "/departments")

# frontend/pages/<m>.py
require_login(roles=["admin", "receptionist"])    # stops page when role not allowed (R31)
with st.form("create_x"):
    name = st.text_input("Name"); ok = st.form_submit_button("Save")
if ok:
    try: call("POST", "/xs", json={"name": name}); st.success("Saved")
    except ApiError as e: st.error(str(e))
```
Rules: API only via api_client (R30); short errors (R32); cache read-only calls (R33); API_URL from env (C05).
