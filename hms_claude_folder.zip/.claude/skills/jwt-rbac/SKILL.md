---
name: jwt-rbac
description: JWT login, bcrypt hashing and require_role dependency for HMS. Use when adding auth or protecting endpoints.
---
# JWT + RBAC (core/security.py)
```python
pwd = CryptContext(schemes=["bcrypt"])
oauth2 = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login")

def hash_password(p): return pwd.hash(p)
def verify_password(p, h): return pwd.verify(p, h)
def create_token(user_id: str, role: str, minutes: int = 60) -> str:
    exp = datetime.now(timezone.utc) + timedelta(minutes=minutes)
    return jwt.encode({"sub": user_id, "role": role, "exp": exp}, settings.secret_key, "HS256")

def get_current_user(token=Depends(oauth2), db=Depends(get_db)) -> User:
    try: data = jwt.decode(token, settings.secret_key, ["HS256"])
    except jwt.PyJWTError: raise HTTPException(401, "Invalid token")
    user = db.get(User, UUID(data["sub"]))
    if not user or not user.status: raise HTTPException(401, "Inactive user")
    return user

def require_role(*roles: str):
    def dep(user: User = Depends(get_current_user)) -> User:
        if user.role not in roles: raise HTTPException(403, "Forbidden")
        return user
    return dep
```
Rules: roles per .claude/specs/_core.md matrix (R11); own-record checks in services (R15); secret_key from env (C05).
