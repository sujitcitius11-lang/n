---
name: pytest-api-tests
description: pytest fixtures and test template for HMS API and Streamlit tests. Use when generating or fixing tests.
---
# pytest setup (tests/conftest.py)
```python
@pytest.fixture(scope="session")
def engine():
    e = create_engine("sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool)
    Base.metadata.create_all(e); return e

@pytest.fixture
def client(engine):
    app.dependency_overrides[get_db] = lambda: Session(engine)
    return TestClient(app)

@pytest.fixture
def auth(client):
    def _h(role): return {"Authorization": f"Bearer {make_user_token(role)}"}   # helper creates fake user
    return _h
```
Per endpoint (R41):
```python
def test_create_ok(client, auth):  assert client.post(URL, json=VALID, headers=auth("receptionist")).status_code == 201
def test_no_token(client):         assert client.post(URL, json=VALID).status_code == 401
def test_wrong_role(client, auth): assert client.post(URL, json=VALID, headers=auth("patient")).status_code == 403
def test_invalid(client, auth):    assert client.post(URL, json={}, headers=auth("receptionist")).status_code == 422
```
Run: `pytest -q -x --tb=short` (R42). Fake data only (R43). Streamlit pages: `AppTest.from_file(...)`.
