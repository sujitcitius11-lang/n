---
name: audit-logging
description: Standard HMS audit trail for every write. Use when adding or changing create/update/delete logic.
---
# Audit logging (services/audit.py)
```python
class AuditLog(Base):
    __tablename__ = "audit_logs"
    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    actor_id: Mapped[uuid.UUID | None]
    action: Mapped[str]        # create | update | delete | login | dispense | pay
    entity: Mapped[str]        # table name
    entity_id: Mapped[uuid.UUID | None]
    ts: Mapped[datetime] = mapped_column(default=lambda: datetime.now(timezone.utc))

def log(db, actor, action, entity, entity_id):
    db.add(AuditLog(actor_id=getattr(actor, "user_id", None), action=action, entity=entity, entity_id=entity_id))
```
Rules: call inside the same transaction as the write (R14); store ids and action only, never field values, names or diagnoses (R13).
