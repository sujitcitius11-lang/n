---
name: sqlalchemy-model-from-spec
description: Maps spec table definitions to SQLAlchemy 2 models. Use when generating models from a module spec.
---
# Spec type -> SQLAlchemy
| Spec | Column |
|---|---|
| UUID PK | `mapped_column(Uuid, primary_key=True, default=uuid.uuid4)` |
| UUID FK | `mapped_column(ForeignKey("t.id"), index=True)` |
| String | `String(n)` (n from spec, else 255) |
| Text | `Text` |
| Enum | Python `enum.Enum` + `SAEnum(E, native_enum=False)` |
| JSON | `JSON().with_variant(JSONB, "postgresql")` |
| Timestamp | `DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)` |
| Decimal | `Numeric(10, 2)` |
| Boolean | `Boolean, default=True` |
```python
class Patient(Base):
    __tablename__ = "patients"
    patient_id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    user_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.user_id"), unique=True)
    user: Mapped["User"] = relationship(lazy="selectin")
```
Rules: names exactly as spec (R21); UUID keys (R20); never create tables outside Alembic migrations (R25).
