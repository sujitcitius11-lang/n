---
name: review-checklist
description: HMS code review checklist ordered by severity. Use when reviewing a git diff.
---
# Review checklist (order per R52)
1. Security [BLOCKER]: endpoint without JWT/role dependency (R10, R11); password in response (R12); PHI or secret in logs (R13); write without audit (R14); no own-record check (R15); unvalidated upload (R16); hardcoded secret.
2. Data/API [MAJOR]: non-UUID key, wrong field names vs spec (R20, R21); logic in router (R22); ORM object returned (R23); N+1 or unpaginated list (R26); appointment overlap/availability check missing (R27); schema change without Alembic (R25).
3. Streamlit [MAJOR]: direct DB/backend import, no role guard, stack trace shown (R30-R32).
4. Tests [MINOR]: missing 401/403/404/422 case (R41); real-looking patient data (R43).
5. Style [MINOR]: missing type hints, ruff failures (C06).
Output exactly per A05: `path:line [SEV] issue -> fix`, max 10 lines.
