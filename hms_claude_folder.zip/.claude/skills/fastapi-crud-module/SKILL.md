---
name: fastapi-crud-module
description: Pattern for one HMS FastAPI module (schema, service, router). Use when scaffolding or extending a module.
---
# FastAPI CRUD module
Files: schemas/<m>.py, services/<m>.py, routers/<m>.py (C03). Logic in services (R22).

```python
# schemas/<m>.py
class XBase(BaseModel): ...                      # fields from spec
class XCreate(XBase): ...
class XRead(XBase):
    id: UUID
    model_config = ConfigDict(from_attributes=True)

# services/<m>.py
def create(db: Session, data: XCreate, actor: User) -> X:
    obj = X(**data.model_dump()); db.add(obj); db.flush()
    audit.log(db, actor, "create", "x", obj.id)   # R14
    db.commit(); return obj

# routers/<m>.py
router = APIRouter(prefix="/api/v1/xs", tags=["xs"])
@router.post("", response_model=XRead, status_code=201)
def create_x(data: XCreate, db: Session = Depends(get_db),
             user: User = Depends(require_role("admin", "receptionist"))):
    return service.create(db, data, user)
```
Checklist: 404 via `HTTPException` when missing; list endpoints take skip/limit; register router in app/main.py; no ORM objects returned.
