# lab_reports (BRD 5.5, 6.7)
Table lab_reports: report_id UUID PK; patient_id UUID FK; test_name String; result_summary Text; report_file String (path); created_by UUID (technician user_id); created_at Timestamp
Endpoints
- POST /lab-reports (lab_technician) multipart: patient_id, test_name, result_summary, file(optional) -> 201
- GET /lab-reports?patient_id= (doctor, admin, lab_technician; patient own)
- GET /lab-reports/{id}
- GET /lab-reports/{id}/file (download, same access as above)
Rules
- Upload constraints per R16 (PDF/PNG/JPG, 5 MB); store under uploads/lab/<uuid>.<ext>, path in report_file.
- uploads/ is git-ignored; never expose the raw path in responses.
- created_by from token (R15); technician cannot edit after creation (admin only).
UI: pages/lab.py - technician upload form; doctor/patient report table with download button.
Open questions: "assigned tests" for technicians not in BRD tables.
