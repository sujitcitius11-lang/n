# prescriptions (BRD 5.4, 6.6)
Table prescriptions: prescription_id UUID PK; appointment_id UUID FK unique; diagnosis Text; medicines JSON [{"name":"Paracetamol","dosage":"1-0-1"}]; created_by UUID (doctor_id)
Endpoints
- POST /prescriptions (doctor) -> 201
- GET /prescriptions/{id} (own doctor, own patient, pharmacist, admin)
- GET /appointments/{id}/prescription
- GET /patients/{id}/prescriptions (own patient, doctor, admin)
Rules
- Doctor can prescribe only for own appointment with status scheduled or completed.
- One prescription per appointment (assumed 1:1); second POST -> 409.
- medicines items validated: name non-empty, dosage pattern like "1-0-1".
- created_by taken from token, never from body (R15).
- Diagnosis and medicines are PHI: never logged (R13).
UI: pages/consultation.py (doctor) - appointment -> diagnosis + medicines editor; patients view own list.
Open questions: lab requests inside consultation not modeled in BRD tables.
