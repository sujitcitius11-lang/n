# Core (shared by all modules)
Source: BRD sections 3, 7, 8. API design below is proposed. BRD says Java Spring Boot; project uses FastAPI by decision.

## Roles (enum Role)
admin, doctor, receptionist, patient, lab_technician, pharmacist, super_admin

## Access matrix (R=read, W=write, own=own records only)
| Module | admin | doctor | receptionist | patient | lab_tech | pharmacist | super_admin |
|---|---|---|---|---|---|---|---|
| auth_users | RW | self | self | self | self | self | RW |
| patients | RW | R | RW | own | - | - | R |
| doctors_departments | RW | R | R | R | - | - | R |
| appointments | R | own R + notes/status | RW | own RW | - | - | R |
| prescriptions | R | own RW | - | own R | - | R | R |
| lab_reports | R | R | - | own R | RW | - | R |
| billing | R | - | RW | own R | - | - | R |
| pharmacy | RW | - | - | - | - | RW | R |
| reports | R | - | - | - | - | - | R |

## Shared rules
- Auth: JWT bearer, 60 min, claims sub=user_id and role.
- Base path /api/v1. Lists take ?skip=0&limit=20 (max 100).
- Error body: {"detail": "<short message>"}.
- Audit: every write -> audit_logs(id, actor_id, action, entity, entity_id, ts).
- Out of scope v1: real-time notifications (log-only stub), microservice split, cloud deploy.
