# appointments (BRD 5.3, 6.5)
Table appointments: appointment_id UUID PK; patient_id UUID FK; doctor_id UUID FK; appointment_date DateTime; status Enum(scheduled,completed,cancelled) default scheduled; notes Text
Endpoints
- POST /appointments (patient own, receptionist) -> 201
- GET /appointments?doctor_id=&patient_id=&date=&status= (role-scoped, R15)
- GET /appointments/{id}
- PATCH /appointments/{id}/cancel (patient own, receptionist)
- PATCH /appointments/{id}/complete {notes} (assigned doctor)
Rules
- R27: no double booking of doctor+slot; slot must fall in doctor availability; no past dates.
- Only status=scheduled can be cancelled or completed; otherwise 409.
- On create/cancel/complete call notify() stub: log-only, no PHI.
- Doctor sees only own appointments; patient only own.
UI: pages/appointments.py - book form (doctor -> date -> free slot), my appointments table with cancel; doctor view with complete form.
Open questions: reminder timing (not in BRD).
