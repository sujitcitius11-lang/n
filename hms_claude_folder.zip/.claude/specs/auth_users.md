# auth_users (BRD 6.1, use case "Register/Login/Logout")
Table users: user_id UUID PK; name String; email String unique; password String (bcrypt hash); role Enum Role; contact_number String; status Boolean default true; created_at Timestamp
Endpoints
- POST /auth/register (public; creates role=patient) -> 201
- POST /auth/login {email,password} -> {access_token, token_type, role}
- POST /auth/logout (stateless; client drops token) -> 204
- GET /users/me (any role)
- POST /users (admin, super_admin) create staff user
- GET /users?role=&skip=&limit= (admin, super_admin)
- PATCH /users/{id}/status (admin, super_admin) activate/deactivate
Rules
- Email stored lowercase, unique; password min 8 chars; never returned (R12).
- Inactive user (status=false) cannot log in -> 403.
- Only admin can create non-patient roles; only super_admin can create admin.
- Log in/out events are audit-logged without email or name (R13).
UI: pages/login.py (login + patient register tabs), sidebar shows role pages.
Open questions: password reset flow not in BRD.
