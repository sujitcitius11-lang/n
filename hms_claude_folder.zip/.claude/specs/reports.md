# reports (BRD 5.8)
No new tables; read-only aggregates over bills, appointments, doctors, departments.
Endpoints (admin, super_admin only)
- GET /reports/daily-revenue?date=YYYY-MM-DD -> {date, total, bills_count}
- GET /reports/patients-seen?from=&to= -> counts per day (completed appointments)
- GET /reports/top-departments?from=&to=&limit=5 -> department + completed count
- Add ?format=csv|pdf to any report to export (csv via stdlib csv; pdf via reportlab)
Rules
- Aggregate in SQL (GROUP BY), never load rows into Python (R26).
- Revenue counts bills with payment_status=paid by created_at date.
- Outputs contain no patient names or other PHI (R13).
- Date range max 366 days.
UI: pages/reports.py - date pickers, st.dataframe + st.bar_chart, download button.
