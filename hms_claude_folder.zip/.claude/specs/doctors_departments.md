# doctors_departments (BRD 5.2, 6.3, 6.4)
Table departments: department_id UUID PK; name String unique; description Text
Table doctors: doctor_id UUID PK; user_id UUID FK users unique; department_id UUID FK departments; qualification String; availability JSON
Availability format: {"Mon":"10-14","Tue":"14-18"} (24h, start-end; BRD example "10-2" normalized).
Endpoints
- POST/PUT/DELETE /departments (admin)
- GET /departments (all roles)
- POST /doctors (admin) -> creates users row (role=doctor) + doctors row
- PUT /doctors/{id} (admin; doctor may update own availability)
- GET /doctors?department_id=&skip=&limit= (all roles)
- GET /doctors/{id}/slots?date=YYYY-MM-DD -> free slots (availability minus booked, 30 min)
Rules
- Department cannot be deleted while doctors reference it -> 409.
- Availability validated by schema: valid weekdays, start < end.
UI: pages/doctors.py - doctor list by department, admin add/edit form.
Open questions: slot length (assumed 30 min).
