# patients (BRD 5.1, 6.2)
Table patients: patient_id UUID PK; user_id UUID FK users unique; gender Enum(male,female,other); dob Date; blood_group String(3); address Text; emergency_contact String(20); allergies Text (comma-separated)
Endpoints
- POST /patients (admin, receptionist, patient self) -> 201
- GET /patients?q=&skip=&limit= (admin, receptionist, doctor)
- GET /patients/{id} (staff or own patient)
- PUT /patients/{id} (admin, receptionist; patient may edit only address, emergency_contact)
- GET /patients/{id}/history -> appointments + prescriptions + lab reports (doctor, own patient)
Rules
- Creating a patient also creates the linked users row (role=patient) when none exists.
- patient_id generated server-side (R20).
- /history is a read-only aggregation; use eager loading (R26).
- Never log name, dob, contact (R13).
UI: pages/patients.py - search table, register form, detail with History tab.
