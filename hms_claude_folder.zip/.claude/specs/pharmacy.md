# pharmacy (BRD 5.7, 6.9)
Table medicines: medicine_id UUID PK; name String unique; quantity_available Integer >= 0; expiry_date Date; unit_price Decimal(10,2)
Endpoints
- POST /medicines, PUT /medicines/{id} (pharmacist, admin)
- GET /medicines?q=&skip=&limit= (pharmacist, admin)
- GET /medicines/alerts?threshold=10 -> low stock + expired (pharmacist, admin)
- POST /pharmacy/dispense {prescription_id, items:[{name, quantity}]} (pharmacist)
Rules
- Dispense runs in one transaction: validate every item, then decrement stock.
- Reject expired medicine or insufficient stock -> 409, nothing decremented.
- Items must match medicines listed on the prescription.
- Stock changes are audit-logged (R14).
UI: pages/pharmacy.py - stock table with alerts, dispense form by prescription id.
Open questions: BRD prescriptions carry no quantity; dispense body supplies it.
