# billing (BRD 5.6, 6.8)
Table bills: bill_id UUID PK; patient_id UUID FK; services JSON [{"name":"Consultation","amount":500.00}]; total_amount Decimal(10,2); payment_status Enum(unpaid,partially_paid,paid) default unpaid; payment_mode Enum(cash,card,online) nullable; created_at Timestamp
Endpoints
- POST /bills (receptionist) -> 201
- GET /bills?patient_id=&payment_status= (receptionist, admin; patient own)
- GET /bills/{id}
- PATCH /bills/{id}/payment {payment_status, payment_mode} (receptionist)
Rules
- total_amount computed server-side = sum of services[].amount; client value ignored.
- Money uses Decimal, never float; amounts > 0.
- payment_mode required when payment_status is not unpaid.
- A paid bill cannot be edited; only admin may void (409 otherwise).
- Every payment change is audit-logged (R14).
UI: pages/billing.py - receptionist builds service list, marks payment; patient sees own bills.
Open questions: paid_amount for partial payments is not in the BRD table.
