#!/usr/bin/env python3
"""Append one JSONL record per hook event to <cfg>/logs/YYYY-MM-DD.jsonl.
Logs event, agent, tool, target path, first 2 words of a command, status and (on Stop) token totals.
Never logs file contents, prompts, full commands or tool output."""
import datetime as dt
import json
import sys
import time
from pathlib import Path

LOGS = Path(__file__).resolve().parent.parent / "logs"
KEEP_DAYS = 7
TOKEN_KEYS = ("input_tokens", "output_tokens", "cache_read_input_tokens", "cache_creation_input_tokens")


def token_totals(path):
    seen = {}
    try:
        with open(path, encoding="utf-8") as f:
            for line in f:
                try:
                    msg = (json.loads(line).get("message") or {})
                except ValueError:
                    continue
                if isinstance(msg.get("usage"), dict):
                    seen[msg.get("id") or len(seen)] = msg["usage"]
    except OSError:
        return None
    return {k: sum(int(u.get(k) or 0) for u in seen.values()) for k in TOKEN_KEYS}


def prune():
    cutoff = time.time() - KEEP_DAYS * 86400
    for p in LOGS.glob("*.jsonl"):
        if p.stat().st_mtime < cutoff:
            p.unlink(missing_ok=True)


def main():
    try:
        data = json.load(sys.stdin)
    except ValueError:
        return
    LOGS.mkdir(exist_ok=True)
    now = dt.datetime.now()
    ti = data.get("tool_input") or {}
    event = data.get("hook_event_name", "")
    rec = {"ts": now.isoformat(timespec="seconds"), "event": event,
           "session": (data.get("session_id") or "")[:8],
           "agent": data.get("agent_type") or "main", "tool": data.get("tool_name")}
    target = ti.get("file_path") or ti.get("path") or ti.get("pattern")
    if target:
        rec["target"] = str(target)[:200]
    if ti.get("command"):
        rec["cmd"] = " ".join(str(ti["command"]).split()[:2])
    resp = data.get("tool_response")
    if event == "PostToolUse":
        bad = isinstance(resp, dict) and (resp.get("is_error") or resp.get("error"))
        rec["status"] = "error" if bad else "ok"
    if event in ("Stop", "SubagentStop"):
        tokens = token_totals(data.get("transcript_path", ""))
        if tokens:
            rec["tokens"] = tokens
        prune()
    with open(LOGS / f"{now:%Y-%m-%d}.jsonl", "a", encoding="utf-8") as f:
        f.write(json.dumps(rec) + "\n")


if __name__ == "__main__":
    main()
