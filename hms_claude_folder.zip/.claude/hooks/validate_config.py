#!/usr/bin/env python3
"""Validate agents, prompts, specs and rule IDs. Silent on success; exit 1 with max 10 lines on failure."""
import re
import sys
from pathlib import Path

CFG = Path(__file__).resolve().parent.parent
KEYS = {"name", "description", "tools", "model", "argument-hint", "user-invocable"}
errs = []


def frontmatter(text):
    lines = text.splitlines()
    if not lines or lines[0] != "---":
        return None
    try:
        end = lines.index("---", 1)
    except ValueError:
        return None
    return {m.group(1): m.group(2) for l in lines[1:end] if (m := re.match(r"^([\w-]+):\s*(.*)$", l))}


def id_range(text):
    ids, rest = set(), text
    for m in re.finditer(r"\b([RAC])(\d{2})\s*-\s*([RAC]?)(\d{2})\b", text):
        if m.group(3) in ("", m.group(1)):
            ids |= {f"{m.group(1)}{n:02d}" for n in range(int(m.group(2)), int(m.group(4)) + 1)}
    rest = re.sub(r"\b([RAC])(\d{2})\s*-\s*([RAC]?)(\d{2})\b", " ", text)
    ids |= {f"{a}{b}" for a, b in re.findall(r"\b([RAC])(\d{2})\b", rest)}
    return ids


def main():
    instr = next((CFG / n for n in ("instructions.md", "copilot-instructions.md") if (CFG / n).exists()), None)
    if not instr:
        errs.append("instructions file missing")
        defined = set()
    else:
        defined = set(re.findall(r"^([RAC]\d{2})\b", instr.read_text(encoding="utf-8"), re.M))
    agents = {p.name.removesuffix(".agent.md") for p in (CFG / "agents").glob("*.agent.md")}
    files = list((CFG / "agents").glob("*.agent.md")) + list((CFG / "prompts").glob("*.prompt.md")) \
        + list((CFG / "skills").glob("*/SKILL.md")) + ([instr] if instr else [])
    for p in files:
        text = p.read_text(encoding="utf-8")
        for i in sorted(id_range(text) - defined):
            errs.append(f"{p.name}: unknown ID {i}")
        n = len(text.splitlines())
        fm = frontmatter(text)
        if p.name.endswith(".agent.md"):
            if n > 20:
                errs.append(f"{p.name}: {n} lines (max 20)")
            if fm is None or set(fm) != KEYS:
                errs.append(f"{p.name}: frontmatter keys must be exactly {sorted(KEYS)}")
            elif fm["name"] != p.name.removesuffix(".agent.md"):
                errs.append(f"{p.name}: name does not match file name")
            for h in ("## Responsibility", "## Constraints"):
                if h not in text:
                    errs.append(f"{p.name}: missing {h}")
        elif p.name.endswith(".prompt.md"):
            if n > 12:
                errs.append(f"{p.name}: {n} lines (max 12)")
            if not fm or fm.get("agent") not in agents:
                errs.append(f"{p.name}: agent missing or unknown")
    for p in (CFG / "specs").glob("*.md"):
        n = len(p.read_text(encoding="utf-8").splitlines())
        if n > 60:
            errs.append(f"{p.name}: {n} lines (max 60, A06)")
    if errs:
        print("\n".join(errs[:10]), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
