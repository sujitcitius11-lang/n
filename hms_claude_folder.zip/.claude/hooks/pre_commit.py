#!/usr/bin/env python3
"""Git pre-commit: secret scan, ruff, config validation, pytest for changed modules.
Silent on success; max 10 lines on failure. Install: python <this file> --install"""
import re
import shutil
import subprocess
import sys
from pathlib import Path

CFG = Path(__file__).resolve().parent.parent
SECRET = re.compile(
    r"AKIA[0-9A-Z]{16}|-----BEGIN [A-Z ]*PRIVATE KEY-----"
    r"|(?i:password|passwd|secret|api[_-]?key|token)\s*[:=]\s*['\"][^'\"\s]{8,}['\"]"
)
SAFE = re.compile(r"noqa: secret|getenv|environ|Field\(|example|changeme", re.I)


def run(cmd, cwd=None):
    return subprocess.run(cmd, capture_output=True, text=True, cwd=cwd)


def root():
    return Path(run(["git", "rev-parse", "--show-toplevel"]).stdout.strip())


def fail(lines):
    print("\n".join(lines[:10]), file=sys.stderr)
    sys.exit(1)


def install():
    r = root()
    rel = (CFG / "hooks" / "pre_commit.py").relative_to(r).as_posix()
    hook = r / ".git" / "hooks" / "pre-commit"
    hook.write_text(f'#!/bin/sh\nPY=$(command -v python || command -v python3)\n"$PY" "{rel}"\n')
    hook.chmod(0o755)
    print(f"installed {hook}")


def secrets(r):
    hits, cur = [], ""
    for line in run(["git", "diff", "--cached", "-U0"], r).stdout.splitlines():
        if line.startswith("+++ "):
            cur = line[6:]
        elif line.startswith("+") and SECRET.search(line) and not SAFE.search(line):
            hits.append(f"possible secret in {cur}")
    return hits


def main():
    if "--install" in sys.argv:
        return install()
    r = root()
    names = run(["git", "diff", "--cached", "--name-only", "--diff-filter=ACM"], r).stdout.split()
    py = [n for n in names if n.endswith(".py")]
    errs = secrets(r)
    if errs:
        fail(errs)
    ruff = shutil.which("ruff")
    if py and ruff:
        res = run([ruff, "check", "-q", "--output-format=concise", *py], r)
        if res.returncode:
            fail((res.stdout + res.stderr).strip().splitlines())
    if any(n.startswith((".claude/", ".github/")) for n in names):
        res = run([sys.executable, str(CFG / "hooks" / "validate_config.py")], r)
        if res.returncode:
            fail(res.stderr.strip().splitlines())
    tests = sorted({str(t) for n in py for t in (r / "tests").glob(f"**/test_*{Path(n).stem}*.py")}) \
        if (r / "tests").exists() else []
    if tests:
        res = run([sys.executable, "-m", "pytest", "-q", "-x", "--tb=short", *tests], r)
        if res.returncode:
            fail((res.stdout + res.stderr).strip().splitlines()[-10:])


if __name__ == "__main__":
    main()
