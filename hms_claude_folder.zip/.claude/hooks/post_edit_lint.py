#!/usr/bin/env python3
"""PostToolUse: format + lint only the edited .py file with ruff. Silent on success, max 10 lines on failure."""
import json
import shutil
import subprocess
import sys


def main():
    try:
        data = json.load(sys.stdin)
    except ValueError:
        return
    path = (data.get("tool_input") or {}).get("file_path", "")
    ruff = shutil.which("ruff")
    if not path.endswith(".py") or not ruff:
        return
    subprocess.run([ruff, "format", "-q", path], capture_output=True)
    r = subprocess.run([ruff, "check", "--fix", "-q", "--output-format=concise", path],
                       capture_output=True, text=True)
    if r.returncode:
        print("\n".join((r.stdout + r.stderr).strip().splitlines()[:10]), file=sys.stderr)
        sys.exit(2)


if __name__ == "__main__":
    main()
