#!/usr/bin/env python3
"""Generate the Copilot layout (.github/) from .claude/ (single source of truth).
Maps Claude tool/model names to Copilot names (edit TOOLS/MODELS below), rewrites paths and prompt variables."""
import re
import shutil
from pathlib import Path

SRC = Path(__file__).resolve().parent.parent
DST = SRC.parent / ".github"
TOOLS = {"Read": "read", "Grep": "search", "Glob": "search", "Write": "edit", "Edit": "edit", "Bash": "execute"}
MODELS = {"haiku": "GPT-4.1", "sonnet": "Claude Sonnet 4"}
SKIP = {"sync_github.py", "__pycache__"}


def paths(text):
    return text.replace(".claude/", ".github/")


def agent(text):
    out = []
    for line in paths(text).splitlines():
        if line.startswith("tools:"):
            names = list(dict.fromkeys(TOOLS.get(t.strip(), t.strip()) for t in line[6:].split(",")))
            line = "tools: [" + ", ".join(f"'{n}'" for n in names) + "]"
        elif line.startswith("model:"):
            m = line[6:].strip()
            line = f"model: {MODELS.get(m, m)}"
        out.append(line)
    return "\n".join(out) + "\n"


def prompt(text):
    return re.sub(r"\{(\w+)\}", r"${input:\1}", paths(text))


def copy_tree(sub, fn=None):
    for p in (SRC / sub).rglob("*"):
        if p.is_dir() or any(s in p.parts for s in SKIP) or p.name in SKIP:
            continue
        t = DST / p.relative_to(SRC)
        t.parent.mkdir(parents=True, exist_ok=True)
        if p.suffix == ".md" and fn:
            t.write_text(fn(p.read_text(encoding="utf-8")), encoding="utf-8")
        elif p.suffix == ".md":
            t.write_text(paths(p.read_text(encoding="utf-8")), encoding="utf-8")
        else:
            shutil.copy2(p, t)


def main():
    for sub in ("agents", "prompts", "skills", "specs", "hooks", "logs"):
        shutil.rmtree(DST / sub, ignore_errors=True)
    copy_tree("agents", agent)
    copy_tree("prompts", prompt)
    for sub in ("skills", "specs", "hooks", "logs"):
        copy_tree(sub)
    (DST / "copilot-instructions.md").write_text(
        paths((SRC / "instructions.md").read_text(encoding="utf-8")), encoding="utf-8")
    print(f"synced {sum(1 for _ in DST.rglob('*') if _.is_file())} files to {DST}")


if __name__ == "__main__":
    main()
