#!/usr/bin/env python3
"""PreToolUse guard: block token-wasting reads and destructive shell commands. Silent when allowed."""
import json
import re
import sys

DENY_PATH = re.compile(
    r"(^|[\\/])(\.venv|venv|__pycache__|node_modules|\.git|\.pytest_cache|\.ruff_cache|\.mypy_cache"
    r"|dist|build|htmlcov|logs|uploads)([\\/]|$)"
    r"|\.(lock|log|sqlite3?|db|pyc|zip)$|(^|[\\/])\.env(\.|$)|package-lock\.json$",
    re.I,
)
BASH_RULES = [
    (r"\brm\s+-\w*[rR]", "recursive delete is blocked"),
    (r"git\s+push\b.*(--force|\s-f\b)", "force push is blocked"),
    (r"git\s+reset\s+--hard", "hard reset is blocked"),
    (r"git\s+clean\s+-\w*f", "git clean is blocked"),
    (r"\bdrop\s+(table|database)\b", "DROP is blocked; use an Alembic migration (R25)"),
    (r"\bmkfs\b|\bdd\s+if=", "disk commands are blocked"),
    (r"(curl|wget)[^|]*\|\s*(sh|bash|python)", "piping downloads to a shell is blocked"),
    (r"Remove-Item\b.*-Recurse|\brmdir\s+/s|\bdel\s+/s", "recursive delete is blocked"),
    (r"chmod\s+-R\s+777", "chmod 777 is blocked"),
    (r"\bpip\s+(list|freeze)\b", "large output; use grep on requirements.txt instead"),
    (r"git\s+log\b(?!.*(-n\s*\d|\s-\d|--oneline|--max-count))", "limit output: git log -n 10 --oneline"),
    (r"\bpytest\b(?!.*(\s-q\b|\s-qq\b|--quiet))", "use: pytest -q -x --tb=short (R42)"),
]
READERS = re.compile(r"^\s*(cat|type|head|tail|less|more|Get-Content)\b", re.I)


def block(msg):
    print("BLOCKED: " + msg, file=sys.stderr)
    sys.exit(2)


def main():
    try:
        data = json.load(sys.stdin)
    except ValueError:
        return
    tool = data.get("tool_name", "")
    ti = data.get("tool_input") or {}
    if tool == "Bash":
        cmd = ti.get("command", "")
        for pat, msg in BASH_RULES:
            if re.search(pat, cmd, re.I if "drop" in pat else 0):
                block(msg)
        if READERS.search(cmd) and DENY_PATH.search(cmd):
            block("path is excluded from reading (R03)")
        return
    for key in ("file_path", "path", "glob", "pattern"):
        v = ti.get(key)
        if isinstance(v, str) and not v.startswith("!") and DENY_PATH.search(v):
            block(f"{v} is excluded (R03). Use files under backend/, frontend/, tests/ or specs/.")


if __name__ == "__main__":
    main()
