---
description: Split the BRD into per-module spec files
agent: spec_slicer
---
BRD: {brd_file}
Modules: auth_users, patients, doctors_departments, appointments, prescriptions, lab_reports, billing, pharmacy, reports (+ _core)
Output: .claude/specs/<module>.md
Apply: R04, R21, A06, A07
