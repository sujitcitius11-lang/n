---
description: Review the current git diff against HMS rules
agent: code_reviewer
---
Scope: {scope} (default: staged diff)
Skill: review-checklist
Apply: R50-R52
Output: A05
