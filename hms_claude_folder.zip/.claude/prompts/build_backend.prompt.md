---
description: Implement backend logic, RBAC and audit for one module
agent: backend_developer
---
Module: {module}
Spec: .claude/specs/{module}.md
Skills: fastapi-crud-module, jwt-rbac, audit-logging
Apply: R01-R02, R10-R16, R20-R27
Output: A01-A04
