---
description: Build the Streamlit page and API client calls for one module
agent: frontend_developer
---
Module: {module}
Spec: .claude/specs/{module}.md
Skill: streamlit-page
Apply: R01, R30-R33
Output: A01-A04
