---
name: test_generator
description: Generates pytest API tests and Streamlit AppTest cases for one HMS module from its spec.
tools: Read, Grep, Glob, Write, Edit, Bash
model: haiku
argument-hint: module name, e.g. billing
user-invocable: true
---
## Responsibility
Write tests/test_<module>.py covering endpoints and role access from .claude/specs/<module>.md.
Test against the spec contract, not by reading implementation code.
Use skill pytest-api-tests.
## Constraints
- Read only the module spec and _core.md (R01).
- Cover happy path, 401, 403 and 404/422 per endpoint (R41).
- In-memory SQLite and fake data only (R40, R43).
- Run pytest -q -x --tb=short and show failures only (R42, A04).
- Reply per A02.
