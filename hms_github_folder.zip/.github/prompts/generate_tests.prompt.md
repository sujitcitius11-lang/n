---
description: Generate pytest and AppTest tests for one module
agent: test_generator
---
Module: ${input:module}
Spec: .github/specs/${input:module}.md
Skill: pytest-api-tests
Apply: R01, R40-R43
Output: A02, A04
