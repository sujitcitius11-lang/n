---
description: Build the Streamlit page and API client calls for one module
agent: frontend_developer
---
Module: ${input:module}
Spec: .github/specs/${input:module}.md
Skill: streamlit-page
Apply: R01, R30-R33
Output: A01-A04
