---
description: Scaffold models, schemas and CRUD skeleton for one module
agent: code_generator
---
Module: ${input:module}
Spec: .github/specs/${input:module}.md
Skills: sqlalchemy-model-from-spec, fastapi-crud-module
Apply: R01-R02, R20-R23, C01-C04
Output: A02, A03
