---
name: hms-glossary
description: Short HMS domain glossary and workflow so the BRD never needs rereading. Use for domain questions.
---
# HMS glossary
Roles: admin (manage users, doctors, departments, reports) | doctor (appointments, diagnosis, prescriptions) | receptionist (register patients, book, bill) | patient (self-service, own data) | lab_technician (enter reports) | pharmacist (dispense, stock) | super_admin (analytics, config).
Flow: register patient -> book appointment (doctor availability) -> consultation (diagnosis + prescription, optional lab report) -> bill (consultation, tests, medicines) -> pharmacy dispense -> reports.
Statuses: appointment = scheduled | completed | cancelled; payment = unpaid | partially_paid | paid; payment_mode = cash | card | online.
PHI: name, dob, contact, address, allergies, diagnosis, medicines, lab results. Never log it (R13).
Targets: patient registration < 3 min, bill generation < 2 min.
Details per module: .github/specs/<module>.md.
