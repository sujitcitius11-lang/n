"""Azure AI Search: three indexes (education, FAQ, care-plan guidance) built from the APPROVED documents.

`sync_indexes()` is idempotent: it creates/updates each index, uploads approved documents with embeddings and
removes documents that are no longer approved (Draft, Retired or deleted), so the Foundry agent never cites them.
"""
from __future__ import annotations

import os
from typing import Callable

import config
from src.knowledge import load_documents

DIMENSIONS = int(os.getenv("EMBEDDING_DIMENSIONS", "1536"))
FOLDER_TO_INDEX = {
    "education": config.SEARCH_INDEX_EDU,
    "faq": config.SEARCH_INDEX_FAQ,
    "careplan_guidance": config.SEARCH_INDEX_CAREPLAN,
}


def is_configured() -> bool:
    return bool(config.SEARCH_SERVICE_ENDPOINT and config.FOUNDRY_PROJECT_ENDPOINT and config.TEXT_EMBEDDING_MODEL_NAME)


def build_index(name: str):
    from azure.search.documents.indexes.models import (
        HnswAlgorithmConfiguration, SearchableField, SearchField, SearchFieldDataType, SearchIndex, SemanticConfiguration,
        SemanticField, SemanticPrioritizedFields, SemanticSearch, SimpleField, VectorSearch, VectorSearchProfile,
    )
    fields = [
        SimpleField(name="id", type=SearchFieldDataType.String, key=True, filterable=True),
        SimpleField(name="article_id", type=SearchFieldDataType.String, filterable=True, facetable=True),
        SearchableField(name="title", type=SearchFieldDataType.String),
        SimpleField(name="program", type=SearchFieldDataType.String, filterable=True, facetable=True),
        SimpleField(name="version", type=SearchFieldDataType.String, filterable=True),
        SimpleField(name="scope", type=SearchFieldDataType.String, filterable=True),
        SimpleField(name="doc_type", type=SearchFieldDataType.String, filterable=True),
        SearchableField(name="content", type=SearchFieldDataType.String),
        SearchField(name="content_vector", type=SearchFieldDataType.Collection(SearchFieldDataType.Single), searchable=True,
                    vector_search_dimensions=DIMENSIONS, vector_search_profile_name="vector-profile"),
    ]
    vector_search = VectorSearch(
        algorithms=[HnswAlgorithmConfiguration(name="hnsw-config")],
        profiles=[VectorSearchProfile(name="vector-profile", algorithm_configuration_name="hnsw-config")],
    )
    semantic = SemanticSearch(
        configurations=[SemanticConfiguration(
            name="default-semantic",
            prioritized_fields=SemanticPrioritizedFields(title_field=SemanticField(field_name="title"),
                                                         content_fields=[SemanticField(field_name="content")]))],
        default_configuration_name="default-semantic",
    )
    return SearchIndex(name=name, fields=fields, vector_search=vector_search, semantic_search=semantic)


def _credential():
    from azure.core.credentials import AzureKeyCredential
    from azure.identity import DefaultAzureCredential
    return AzureKeyCredential(config.SEARCH_API_KEY) if config.SEARCH_API_KEY else DefaultAzureCredential()


def embed(texts: list[str]) -> list[list[float]]:
    from azure.ai.projects import AIProjectClient
    from azure.identity import DefaultAzureCredential
    client = AIProjectClient(endpoint=config.FOUNDRY_PROJECT_ENDPOINT, credential=DefaultAzureCredential()).get_openai_client()
    out: list[list[float]] = []
    for i in range(0, len(texts), 16):
        out += [d.embedding for d in client.embeddings.create(model=config.TEXT_EMBEDDING_MODEL_NAME, input=texts[i:i + 16]).data]
    return out


def plan() -> dict[str, list[dict]]:
    by_folder: dict[str, list[dict]] = {f: [] for f in FOLDER_TO_INDEX}
    for d in load_documents():
        by_folder[d["folder"]].append(d)
    return by_folder


def sync_indexes(dry_run: bool = False, progress: Callable[[str], None] = lambda m: None) -> dict:
    by_folder = plan()
    if dry_run:
        for folder, name in FOLDER_TO_INDEX.items():
            idx = build_index(name)
            progress(f"[dry-run] index '{idx.name}' ({len(idx.fields)} fields) <- {len(by_folder[folder])} approved document(s)")
        return {name: len(by_folder[f]) for f, name in FOLDER_TO_INDEX.items()}
    if not is_configured():
        raise RuntimeError("SEARCH_SERVICE_ENDPOINT, FOUNDRY_PROJECT_ENDPOINT and TEXT_EMBEDDING_MODEL_NAME must be set in .env")
    from azure.search.documents import SearchClient
    from azure.search.documents.indexes import SearchIndexClient
    cred = _credential()
    index_client = SearchIndexClient(endpoint=config.SEARCH_SERVICE_ENDPOINT, credential=cred)
    result = {}
    for folder, name in FOLDER_TO_INDEX.items():
        docs = by_folder[folder]
        index_client.create_or_update_index(build_index(name))
        client = SearchClient(endpoint=config.SEARCH_SERVICE_ENDPOINT, index_name=name, credential=cred)
        wanted = {d["article_id"] for d in docs}
        stale = [{"id": r["id"]} for r in client.search(search_text="*", select=["id"], top=1000) if r["id"] not in wanted]
        if stale:
            client.delete_documents(stale)
            progress(f"'{name}': removed {len(stale)} document(s) that are no longer approved")
        if docs:
            vecs = embed([f"{d['title']}\n{d['content']}" for d in docs])
            client.upload_documents([{
                "id": d["article_id"], "article_id": d["article_id"], "title": d["title"], "program": d["program"],
                "version": d["version"], "scope": d.get("scope", ""), "doc_type": folder, "content": d["content"],
                "content_vector": v} for d, v in zip(docs, vecs)])
        progress(f"'{name}': {len(docs)} approved document(s) indexed")
        result[name] = len(docs)
    return result


def refresh_knowledge_sources(progress: Callable[[str], None] = lambda m: None) -> dict:
    """Knowledge-base mode: ask the indexers behind your knowledge sources to read Blob Storage again.

    Names come from KNOWLEDGE_INDEXERS in .env (see the indexers list in the Azure portal; exact names: check docs).
    Deleted/retired files only disappear from the index if the indexer has deletion detection (check docs).
    """
    if not config.KNOWLEDGE_INDEXERS:
        progress("KNOWLEDGE_INDEXERS is empty: refresh the knowledge sources in the portal (or set the indexer names in .env).")
        return {"ran": [], "manual": True}
    from azure.search.documents.indexes import SearchIndexerClient
    client = SearchIndexerClient(endpoint=config.SEARCH_SERVICE_ENDPOINT, credential=_credential())
    ran = []
    for name in config.KNOWLEDGE_INDEXERS:
        client.run_indexer(name)
        progress(f"started indexer '{name}'")
        ran.append(name)
    return {"ran": ran, "manual": False}


def sync_for_current_mode(progress: Callable[[str], None] = lambda m: None) -> dict:
    """The right 'make the search side current' step for EDUCATION_RETRIEVAL."""
    from src.azure_integration import blob
    try:
        out = refresh_knowledge_sources(progress) if config.EDUCATION_RETRIEVAL == "knowledge_base" else sync_indexes(progress=progress)
        blob.record_sync("indexing", True, config.EDUCATION_RETRIEVAL)
        return out
    except Exception as exc:  # noqa: BLE001
        blob.record_sync("indexing", False, f"{type(exc).__name__}: {exc}")
        raise
