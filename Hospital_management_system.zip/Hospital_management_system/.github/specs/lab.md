# Lab orders and reports contract

## Source and status
- BRD/source: Lab Reports table and sections 3-5.5, 9.
- Reviewed by/date: Sliced from user-provided BRD on 2026-10-08.
- Status: draft; open questions below require decisions.

## Scope
- Goal: record test results and make authorized reports available to Doctors and Patients.
- In scope: Lab Technician entry, report metadata/file reference, authorized viewing.
- Out of scope: inventory, billing, and the missing lab-order workflow until specified.

## Roles and permissions
| Role | Allowed actions | Restrictions |
|---|---|---|
| Lab Technician | View assigned tests; enter test reports | Assignment mechanism is not specified; no unassigned patient browsing. |
| Doctor | View relevant lab reports | Scope to authorized patient/care relationship. |
| Patient | View own lab reports | Own-record access only. |
| Receptionist, Admin | No lab access stated | Do not grant clinical access without policy approval. |

## Data contract
| Entity/field | Type/constraints | Sensitivity | Source |
|---|---|---|---|
| LabReport.report_id | UUID, unique ID | Internal identifier | BRD 6.7 |
| patient_id | UUID FK to patient | Patient/care relationship | BRD 6.7 |
| test_name | String | Health data | BRD 6.7 |
| result_summary | Text | Health data | BRD 6.7 |
| report_file | File path/reference (not a client-controlled filesystem path) | Health data | BRD 6.7 |
| created_by | UUID Technician ID; Technician should resolve to User identity | Staff identity | BRD 6.7 |
| created_at | Timestamp | Clinical record metadata | BRD 6.7 |

## API contract
| Method/path | Role | Request/response | Behavior |
|---|---|---|---|
| POST /lab-reports | Assigned Lab Technician | Patient/order, test, result, file upload/reference / report metadata | Verify assignment and store file through approved storage service. |
| GET /lab-reports/{report_id} | Patient (own), authorized Doctor, assigned Technician | ID / metadata and authorized file access | Enforce access scope; do not expose storage path. |
| GET /patients/{patient_id}/lab-reports | Patient (self), authorized Doctor, assigned Technician | Patient ID / report list | Return only permitted patient reports. |

## Workflows and integrity
- State transitions: ordered, collected, pending, final, corrected states are not specified.
- Validation and database constraints: patient FK, technician identity, allowed file types/size, malware scanning, retention, and storage provider need decisions.
- Transaction boundaries: metadata persistence and file upload/delete consistency must be designed.
- Audit events: result entry, correction, upload, and viewing as required by policy; never log result text or file contents.

## UI behavior
- Pages/forms: Lab Technician assigned-work/result entry; Doctor and Patient report list/detail.
- API operations: upload report, list reports, fetch authorized metadata/file.
- Error and empty states: no assigned tests, failed upload, unavailable report, unauthorized download.

## Acceptance tests
- Given an assigned Lab Technician, when valid result metadata is submitted, then it is associated with the patient and creator.
- Given a Patient requests a report belonging to another patient, when accessed, then the request is denied.
- Given an unsupported or oversized file, when uploaded, then it is rejected and no orphan metadata is created.

## Open questions
- [ ] Clinical/BA: define lab-order/test assignment, status workflow, ordering Doctor, and appointment linkage.
- [ ] Security/DevOps: choose private file storage, authorized download mechanism, accepted file types/size, malware scanning, retention, and backup.
- [ ] Clinical: define result correction/amendment and sign-off workflow.
- [ ] BA: clarify whether report upload is a required initial feature or file reference only.
