# Prescriptions and consultation contract

## Source and status
- BRD/source: Prescription table and sections 3-5.4, 7, 9.
- Reviewed by/date: Sliced from user-provided BRD on 2026-10-08.
- Status: draft; open questions below require decisions.

## Scope
- Goal: let Doctors record diagnoses and medication orders after consultation.
- In scope: appointment-linked diagnosis, prescription medicines, creator identity, patient/Doctor viewing.
- Out of scope: dispensing/inventory (pharmacy spec), lab orders/results (lab spec).

## Roles and permissions
| Role | Allowed actions | Restrictions |
|---|---|---|
| Doctor | View relevant patient history; create diagnosis/prescription after visit | Scope to authorized care relationship; amendment rules unspecified. |
| Patient | View own prescriptions and history | Other-patient access denied. |
| Pharmacist | Use prescriptions to dispense medicines | Prescription read/validation workflow needs detail. |
| Admin, Receptionist | No clinical write permission specified | Do not grant access by default. |

## Data contract
| Entity/field | Type/constraints | Sensitivity | Source |
|---|---|---|---|
| Prescription.prescription_id | UUID, unique ID | Internal identifier | BRD 6.6 |
| appointment_id | UUID FK to appointment | Care relationship | BRD 6.6 |
| diagnosis | Text | Health data | BRD 6.6 |
| medicines | JSON array; example name and dosage | Medication/health data | BRD 6.6 |
| created_by | UUID Doctor ID | Clinician identity | BRD 6.6 |
| created_at | Not specified | Clinical record metadata | Timestamp implied by workflow; confirm before adding. |

## API contract
| Method/path | Role | Request/response | Behavior |
|---|---|---|---|
| POST /appointments/{appointment_id}/prescriptions | Assigned Doctor | Diagnosis, medicines / saved prescription | Validate appointment scope and persist creator identity. |
| GET /prescriptions/{prescription_id} | Patient (own), creating/assigned Doctor, Pharmacist for dispensing TBD | ID / prescription | Return only authorized clinical fields. |
| GET /patients/{patient_id}/prescriptions | Patient (self), authorized Doctor; Pharmacist workflow TBD | Patient ID / prescription list | Scope records by patient and caller permissions. |
| PATCH /prescriptions/{prescription_id} | Doctor policy TBD | Corrected fields / updated prescription | Do not allow silent clinical history overwrite; amendment policy required. |

## Workflows and integrity
- State transitions: created/active/discontinued/refilled status is not defined in the BRD.
- Validation and database constraints: appointment and doctor FKs; medicines JSON schema and dosage/units are undefined.
- Transaction boundaries: prescription save and any linked appointment completion should follow an approved atomicity policy.
- Audit events: create/update clinical records with minimal metadata; never include diagnosis or medicines in audit detail.

## UI behavior
- Pages/forms: Doctor consultation screen; Patient prescription/history view.
- API operations: read patient history, save diagnosis/prescription, list own history.
- Error and empty states: no linked appointment/history, invalid medicine details, and forbidden access.

## Acceptance tests
- Given an authorized Doctor and eligible appointment, when a valid prescription is saved, then it is linked to that appointment and creator.
- Given a Patient requests another patient's prescription, when fetched, then access is denied.
- Given invalid medicine payload data, when submitted, then validation fails and no partial record is saved.

## Open questions
- [ ] Clinical/BA: define medicine structure (strength, route, frequency, duration, quantity, units) and diagnosis coding/free text.
- [ ] Clinical/BA: define whether multiple prescriptions per appointment, amendments, cancellation, refills, and signing are allowed.
- [ ] Security: define Pharmacist visibility and Patient release timing.
- [ ] BA: confirm whether prescription creation also marks an appointment Completed and whether a separate diagnosis/consultation entity is needed.
