# Doctors and departments contract

## Source and status
- BRD/source: Doctors and Departments tables and sections 3-4, 5.2, 5.8.
- Reviewed by/date: Sliced from user-provided BRD on 2026-10-08.
- Status: draft; open questions below require decisions.

## Scope
- Goal: manage doctors, their department assignment, and availability.
- In scope: Admin doctor registration/management; department and service management; doctor appointment visibility.
- Out of scope: appointment booking (appointments spec), clinical notes (prescriptions spec).

## Roles and permissions
| Role | Allowed actions | Restrictions |
|---|---|---|
| Admin | Manage doctors, departments, and services | Service data fields are absent from the BRD. |
| Doctor | View assigned appointments and own availability/profile as approved | Change permissions are unspecified. |
| Patient, Receptionist | Read scheduling-facing doctor/department information | Visibility and search fields require approval. |

## Data contract
| Entity/field | Type/constraints | Sensitivity | Source |
|---|---|---|---|
| Doctor.doctor_id | UUID, unique ID | Internal identifier | BRD 6.3 |
| Doctor.user_id | UUID FK to Users | Identity link | BRD 6.3 |
| Doctor.department_id | UUID FK to Departments | Organizational data | BRD 6.3 |
| Doctor.qualification | String | Professional data | BRD 6.3 |
| Doctor.availability | JSON weekday-to-time ranges (example only) | Scheduling data | BRD 6.3 |
| Department.department_id, name, description | UUID, string, text | Organizational data | BRD 6.4 |
| Services | Mentioned in use cases; no entity/fields supplied | Unknown | BRD 3-4 |

## API contract
| Method/path | Role | Request/response | Behavior |
|---|---|---|---|
| POST /doctors | Admin | User link, department, qualification, availability / doctor profile | Create/link doctor with valid department. |
| GET /doctors and GET /doctors/{doctor_id} | Admin, Doctor; scheduling read for Patient/Receptionist TBD | Filters/ID / profile and availability | Return only scheduling-approved fields. |
| PATCH /doctors/{doctor_id} | Admin | Editable doctor fields / profile | Validate department and availability; audit changes. |
| CRUD /departments | Admin writes; read roles TBD | Department fields / department record | Manage department name and description. |
| CRUD /services | Admin writes; read roles TBD | Undefined service schema | Block implementation until service fields and behavior are approved. |

## Workflows and integrity
- State transitions: doctor/department lifecycle is unspecified; do not assume hard deletion.
- Validation and database constraints: UUID keys and FKs; availability JSON schema, timezone, overlapping ranges, and department uniqueness need definition.
- Transaction boundaries: doctor and linked User creation should be atomic.
- Audit events: Admin changes to doctors, departments, services, and availability; no PHI.

## UI behavior
- Pages/forms: Admin management of doctors, departments, services; scheduling-facing doctor lookup.
- API operations: directory reads and Admin writes using the shared API client.
- Error and empty states: unavailable doctors and empty directories; do not show undefined service features.

## Acceptance tests
- Given an Admin creates a doctor for an existing department, when valid data is saved, then the doctor is linked to that department.
- Given a doctor has configured availability, when an authorized scheduling user views the directory, then only approved availability data is shown.
- Given a nonexistent department ID, when a doctor is created, then the request is rejected without a partial user/doctor record.

## Open questions
- [ ] BA: define Services fields, pricing, relationships to departments, and allowed management/read roles.
- [ ] BA: define availability schema, timezone, slot duration, exceptions, and validation rules.
- [ ] BA/Security: define which doctor fields Patients and Receptionists may view.
- [ ] BA: define doctor onboarding, account link uniqueness, and deactivation/deletion behavior.
