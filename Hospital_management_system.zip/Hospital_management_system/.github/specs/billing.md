# Billing and payments contract

## Source and status
- BRD/source: Billing table and sections 3-4, 5.6, 7, 9-10.
- Reviewed by/date: Sliced from user-provided BRD on 2026-10-08.
- Status: draft; open questions below require decisions.

## Scope
- Goal: generate patient invoices from consultation, tests, and medicines and track payment status/mode.
- In scope: bill creation, totals, payment marking, Patient/Receptionist access.
- Out of scope: accounting ledger, refunds, tax, discounts, and payment gateway integration unless approved.

## Roles and permissions
| Role | Allowed actions | Restrictions |
|---|---|---|
| Receptionist | Issue bills; mark payment according to approved process | Payment amount, edit, and void powers unspecified. |
| Patient | View own bills; make/record payment per approved channel | Must not alter bill amounts or mark self-paid without verified payment. |
| Admin | Manage billing as stated in actor responsibilities | Exact permissions and separation of duties unspecified. |

## Data contract
| Entity/field | Type/constraints | Sensitivity | Source |
|---|---|---|---|
| Bill.bill_id | UUID, unique ID | Financial identifier | BRD 6.8 |
| patient_id | UUID FK to patient | Patient/financial data | BRD 6.8 |
| services | JSON list of services and amounts | Financial data | BRD 6.8 |
| total_amount | Decimal | Financial data | BRD 6.8 |
| payment_status | Enum: Paid, Unpaid, Partially Paid | Financial data | BRD 6.8 |
| payment_mode | Enum: Cash, Card, Online | Financial data | BRD 6.8 |
| created_at | Timestamp | Financial record metadata | BRD 6.8 |

## API contract
| Method/path | Role | Request/response | Behavior |
|---|---|---|---|
| POST /bills | Receptionist, Admin under policy | Patient, billable items / invoice | Recalculate total server-side and persist immutable item/price snapshot. |
| GET /bills/{bill_id} | Patient (own), Receptionist, Admin | ID / invoice | Enforce ownership and role scope. |
| GET /patients/{patient_id}/bills | Patient (self), Receptionist, Admin | Patient ID / bills | Return authorized invoice history. |
| POST /bills/{bill_id}/payments | Authorized Receptionist/Admin or verified payment callback | Amount, mode, reference / payment status | Record payment atomically; never trust client-supplied resulting status. |

## Workflows and integrity
- State transitions: Unpaid/Partially Paid/Paid depend on payments; exact transitions and reversals are undefined.
- Validation and database constraints: decimal precision/currency, nonnegative amounts, immutable item snapshots, and valid patient FK.
- Transaction boundaries: bill items, total, and payment ledger/status updates must be atomic and concurrency-safe.
- Audit events: bill creation, adjustment, payment, void/refund; never record payment credentials or sensitive card data.
- Production payment processing is not described; Cash/Card/Online are only payment-mode labels in the BRD.

## UI behavior
- Pages/forms: Receptionist invoice creation/payment recording; Patient bill history/payment entry if enabled.
- API operations: create/read bills and record payments.
- Error and empty states: invalid amount, duplicate payment reference, already-paid invoice, and unauthorized patient bill.

## Acceptance tests
- Given billable items, when a bill is created, then the server-calculated total equals the approved item sum.
- Given partial payment, when committed, then the status is derived as Partially Paid and the outstanding balance is correct.
- Given concurrent payments, when applied, then the invoice is not overpaid or assigned an incorrect status.

## Open questions
- [ ] Finance/BA: define currency, rounding, taxes, discounts, service catalog/prices, item snapshot fields, and bill numbering.
- [ ] Finance/Security: define payment verification, gateway/callback, reconciliation, refunds, voids, and permitted payment actors.
- [ ] BA: define whether payment_mode may be null for Unpaid bills and how partial payments with multiple modes are represented.
- [ ] BA: define linkages to appointments, lab tests, and dispensed medicines; these source entities are not fully modeled in the BRD.
