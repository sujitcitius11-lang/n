# Module specifications

Keep each module contract in its own 40-80 line Markdown file, based on [TEMPLATE.md](./TEMPLATE.md). Contracts identify source-backed requirements and unresolved questions; they are the implementation agents' input, not a replacement for the BRD.

Initial draft slices from the BRD supplied in chat are present: [Auth](./auth.md), [Patients](./patients.md), [Doctors and Departments](./doctors-departments.md), [Appointments](./appointments.md), [Prescriptions](./prescriptions.md), [Lab](./lab.md), [Billing](./billing.md), [Pharmacy](./pharmacy.md), and [Reports](./reports.md). Review and approve each spec before implementation.

Services are mentioned by the BRD but do not have a data contract; their unresolved requirements are tracked in the Doctors and Departments spec.
