# Patients contract

## Source and status
- BRD/source: Patient table and sections 3-5, 7.
- Reviewed by/date: Sliced from user-provided BRD on 2026-10-08.
- Status: draft; open questions below require decisions.

## Scope
- Goal: register patients and maintain demographic and medical-history profile data.
- In scope: self-registration, Receptionist registration, Admin/Receptionist management, patient history visibility.
- Out of scope: diagnoses and prescriptions (prescriptions spec), lab results (lab spec), billing.

## Roles and permissions
| Role | Allowed actions | Restrictions |
|---|---|---|
| Patient | Self-register; view own history and prescriptions | Own-record access only; profile editing policy unspecified. |
| Receptionist | Register and manage patient profiles | Exact editable fields and search scope unspecified. |
| Admin | Manage patient records | Access purpose and audit detail unspecified. |
| Doctor | View patient history for care | Assignment/relationship restriction unspecified. |

## Data contract
| Entity/field | Type/constraints | Sensitivity | Source |
|---|---|---|---|
| Patient.patient_id | UUID, unique ID | Patient identifier | BRD 6.2 |
| Patient.user_id | UUID FK to Users | Identity link | BRD 6.2 |
| Patient.gender | Enum: Male, Female, Other | Sensitive personal data | BRD 6.2 |
| Patient.dob | Date | Sensitive personal data | BRD 6.2 |
| Patient.blood_group | String | Health data | BRD 6.2 |
| Patient.address, emergency_contact | Text/string | Personal data | BRD 6.2 |
| Patient.allergies | Text; BRD describes comma-separated values | Health data | BRD 6.2 |
| Medical history | Mentioned in workflow but no fields/schema supplied | Health data | BRD 5.1, 5.4 |

## API contract
| Method/path | Role | Request/response | Behavior |
|---|---|---|---|
| POST /patients | Patient or Receptionist | Account/profile details / patient ID and safe profile | Create a patient and associated user consistently; self-registration must not set roles. |
| GET /patients/{patient_id} | Patient (self), Doctor, Receptionist, Admin | ID / authorized profile | Return only fields caller is permitted to view. |
| GET /patients | Receptionist, Admin; Doctor only if care scope allows | Search/filter / authorized patient summaries | Enforce access scope; pagination contract to be decided. |
| PATCH /patients/{patient_id} | Receptionist, Admin; Patient self-edit policy TBD | Profile fields / updated safe profile | Validate permitted-field changes and audit the write. |

## Workflows and integrity
- State transitions: registration and subsequent profile updates; lifecycle/deletion is unspecified.
- Validation and database constraints: patient ID UUID; user FK required; allergy representation and duplicate patient detection need definition.
- Transaction boundaries: patient and associated user creation must be atomic.
- Audit events: patient registration and profile changes without recording PHI in audit details.

## UI behavior
- Pages/forms: self-registration and staff patient registration/search/profile.
- API operations: patient create/read/update through the shared API client.
- Error and empty states: duplicate/invalid input and unauthorized access handled explicitly without exposing another patient's existence unnecessarily.

## Acceptance tests
- Given a valid registration, when submitted by a Patient or Receptionist, then one linked User and Patient are created with a UUID patient ID.
- Given a Patient requests another patient's profile, when the profile is fetched, then access is denied.
- Given an authorized profile update, when saved, then the change is persisted and audited without PHI in the audit payload.

## Open questions
- [ ] BA: define medical-history fields, allergy structure, patient identifier display format, and duplicate-match rules.
- [ ] BA/Security: define patient self-edit fields and Doctor access scope (e.g. assigned appointments only).
- [ ] BA: clarify patient registration account verification and required fields.
- [ ] BA/Engineering: determine whether patient records can be archived/deactivated and retention requirements.
