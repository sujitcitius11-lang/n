# Auth and users contract

## Source and status
- BRD/source: User table and sections 3, 4, 7.
- Reviewed by/date: Sliced from user-provided BRD on 2026-10-08.
- Status: draft; open questions below require decisions.

## Scope
- Goal: authenticate actors and manage user identities and account status.
- In scope: registration, login, logout, role assignment, user administration.
- Out of scope: patient clinical profile fields (patients spec), authorization policy details not stated in BRD.

## Roles and permissions
| Role | Allowed actions | Restrictions |
|---|---|---|
| Admin | Manage users | Exact role assignment and deletion powers unspecified. |
| Patient | Self-register, authenticate, logout | Must not self-assign a privileged role. |
| Doctor, Receptionist, Lab Technician, Pharmacist | Authenticate, logout | Provisioning and permitted account changes unspecified. |
| Super Admin (optional) | Hospital configuration and oversight | Whether enabled and how it differs from Admin are unspecified. |

## Data contract
| Entity/field | Type/constraints | Sensitivity | Source |
|---|---|---|---|
| User.user_id | UUID, unique ID | Internal identifier | BRD 6.1 |
| User.name, email, contact_number | String; email is login email | Personal data | BRD 6.1 |
| User.password | Encrypted in BRD; implement as a one-way bcrypt hash, never return it | Credential | BRD 6.1, 7 |
| User.role | Enum: Admin, Doctor, Receptionist, Patient, Lab Technician, Pharmacist; optional Super Admin | Authorization data | BRD 3, 6.1 |
| User.status | Boolean active/inactive | Account data | BRD 6.1 |
| User.created_at | Timestamp | Audit metadata | BRD 6.1 |

## API contract
| Method/path | Role | Request/response | Behavior |
|---|---|---|---|
| POST /auth/register | Public patient registration; staff provisioning Admin-only pending decision | Registration fields / safe user profile | Create a Patient account; never accept a caller-selected privileged role. |
| POST /auth/login | All active users | Email/password / JWT and safe identity | Verify credentials and active status; token claims and lifetime need approval. |
| POST /auth/logout | Authenticated user | Auth context / success | Logout behavior depends on token revocation policy. |
| GET /users | Admin | Filters / safe user list | List user identities without password hashes. |
| PATCH /users/{user_id} | Admin | Permitted account fields / safe profile | Update account status or role only according to approved policy. |

## Workflows and integrity
- State transitions: active/inactive; password reset, lockout, and account deletion are undefined.
- Validation and database constraints: unique normalized email, role allowlist, password hashing, UUID key.
- Transaction boundaries: user and related role/profile creation must not leave partial identities.
- Audit events: registration, login/logout outcomes as policy permits, role/status changes; never log passwords or tokens.

## UI behavior
- Pages/forms: registration, login/logout, and Admin user management.
- API operations: use auth endpoints and shared HTTP client.
- Error and empty states: safe generic credential failure; distinguish inactive-account handling only after policy decision.

## Acceptance tests
- Given valid credentials for an active user, when they log in, then a valid token and no password/hash are returned.
- Given a self-registration request containing an Admin role, when submitted, then privilege escalation is rejected or the role is ignored according to approved API behavior.
- Given an inactive user, when authentication is attempted, then access is denied.

## Open questions
- [ ] BA/Security: confirm whether optional Super Admin is in scope and define role hierarchy/permissions.
- [ ] BA/Security: define account provisioning, password policy/reset, JWT claims/expiry, logout revocation, and email normalization.
- [ ] BA/Engineering: resolve BRD's Java Spring Boot and Angular/React non-functional stack statements against the selected FastAPI/Streamlit architecture.
- [ ] BA: define user deletion/deactivation behavior and whether staff roles are assignable only by Admin.
