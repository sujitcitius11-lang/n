# Appointments contract

## Source and status
- BRD/source: Appointments table and sections 3-5, 9-10.
- Reviewed by/date: Sliced from user-provided BRD on 2026-10-08.
- Status: draft; open questions below require decisions.

## Scope
- Goal: schedule and manage patient appointments with doctors.
- In scope: Patient/Receptionist booking, Doctor appointment visibility and completion, cancellation, notifications.
- Out of scope: diagnosis/prescription content (prescriptions spec), billing (billing spec).

## Roles and permissions
| Role | Allowed actions | Restrictions |
|---|---|---|
| Patient | Book/manage own appointments | Other-patient access denied; cancellation rules unspecified. |
| Receptionist | Book/manage appointments for patients | Exact update/cancel permissions unspecified. |
| Doctor | View assigned appointments; update after visit | May not change another doctor's appointment; completion rules unspecified. |
| Admin | No appointment permission explicitly specified | Do not grant access without policy approval. |

## Data contract
| Entity/field | Type/constraints | Sensitivity | Source |
|---|---|---|---|
| Appointment.appointment_id | UUID, unique ID | Internal identifier | BRD 6.5 |
| patient_id, doctor_id | UUID FKs | Patient/care relationship | BRD 6.5 |
| appointment_date | DateTime | Scheduling data | BRD 6.5 |
| status | Enum: Scheduled, Completed, Cancelled | Care workflow data | BRD 6.5 |
| notes | Text visit summary by Doctor | Health data | BRD 6.5 |

## API contract
| Method/path | Role | Request/response | Behavior |
|---|---|---|---|
| POST /appointments | Patient (self), Receptionist | Patient, doctor, date/time / appointment | Confirm patient scope, doctor availability, and no conflicting booking. |
| GET /appointments/{appointment_id} | Patient (own), assigned Doctor, Receptionist | ID / appointment | Return only records within caller's permitted scope. |
| GET /appointments | Patient (own), Doctor (assigned), Receptionist | Filters / list | Enforce ownership/assignment; pagination to be defined. |
| PATCH /appointments/{appointment_id} | Patient/Receptionist/Doctor within policy | Approved fields / appointment | Permit only allowed state transitions and audit changes. |

## Workflows and integrity
- State transitions: Scheduled -> Completed or Cancelled are suggested by status values; exact transition rules need approval.
- Validation and database constraints: patient/doctor FKs; prevent double-booking atomically; validate doctor availability.
- Transaction boundaries: availability/conflict check and booking must be serialized or protected by an equivalent database constraint.
- Audit events: create, reschedule, cancel, completion, and note changes; do not put visit notes in audit details.
- Notification: BRD requires doctor/patient notification but channel, timing, retry, and consent are undefined.

## UI behavior
- Pages/forms: Patient booking/manage view, Receptionist scheduler, Doctor assigned-appointments view.
- API operations: doctor availability lookup, create/list/update appointments.
- Error and empty states: unavailable slot, conflict, forbidden record, and no appointments.

## Acceptance tests
- Given an available slot, when an authorized Patient books it, then one Scheduled appointment is created.
- Given two simultaneous requests for the same doctor/time, when both attempt booking, then at most one succeeds.
- Given a Patient requests another patient's appointment, when fetched, then access is denied.

## Open questions
- [ ] BA: define appointment duration, slot granularity, timezone, working hours, holidays, and buffer time.
- [ ] BA: define reschedule/cancel rules, allowed state transitions, no-show status, and Doctor completion behavior.
- [ ] BA/Security: define Receptionist and Doctor field-level permissions and visit-note editing policy.
- [ ] Product/Engineering: decide notification channels, delivery timing, failure handling, and whether notification is in initial scope.
