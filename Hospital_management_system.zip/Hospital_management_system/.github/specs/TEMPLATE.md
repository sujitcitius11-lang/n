# <Module> contract

## Source and status
- BRD/source:
- Reviewed by/date:
- Status: draft | approved

## Scope
- Goal:
- In scope:
- Out of scope:

## Roles and permissions
| Role | Allowed actions | Restrictions |
|---|---|---|
| | | |

## Data contract
| Entity/field | Type/constraints | Sensitivity | Source |
|---|---|---|---|
| | | | |

## API contract
| Method/path | Role | Request/response | Behavior |
|---|---|---|---|
| | | | |

## Workflows and integrity
- State transitions:
- Validation and database constraints:
- Transaction boundaries:
- Audit events:

## UI behavior
- Pages/forms:
- API operations:
- Error and empty states:

## Acceptance tests
- Given / when / then:

## Open questions
- [ ] Question, owner, and decision needed:
