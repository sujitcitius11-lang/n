# Reports and analytics contract

## Source and status
- BRD/source: Sections 3-4, 5.8, 7-10.
- Reviewed by/date: Sliced from user-provided BRD on 2026-10-08.
- Status: draft; open questions below require decisions.

## Scope
- Goal: provide management reports for daily revenue, patients seen, and top departments.
- In scope: Admin and optional Super Admin access; CSV/PDF export.
- Out of scope: unlisted metrics, predictive analytics, backups, and real-time dashboards.

## Roles and permissions
| Role | Allowed actions | Restrictions |
|---|---|---|
| Admin | View reports and export | Exact report visibility and data granularity unspecified. |
| Super Admin (optional) | Analytics and oversight | Existence and additional scope require approval. |
| Other roles | No report access stated | Deny by default. |

## Data contract
| Entity/field | Type/constraints | Sensitivity | Source |
|---|---|---|---|
| Daily revenue | Aggregation over billing/payment records; formula unspecified | Financial data | BRD 5.8 |
| Patients seen | Aggregation over appointment/consultation records; definition unspecified | Potentially sensitive aggregate | BRD 5.8 |
| Top departments | Department aggregation; ranking measure unspecified | Operational data | BRD 5.8 |
| Export | CSV/PDF | May contain sensitive information | BRD 5.8 |

## API contract
| Method/path | Role | Request/response | Behavior |
|---|---|---|---|
| GET /reports/revenue | Admin, Super Admin if enabled | Date range / aggregated revenue | Apply approved date, timezone, payment, and refund rules. |
| GET /reports/patients-seen | Admin, Super Admin if enabled | Date range / aggregate count | Use approved definition; do not include patient identifiers by default. |
| GET /reports/departments | Admin, Super Admin if enabled | Date range / ranked aggregates | Use approved ranking metric and tie handling. |
| GET /reports/{report}/export?format=csv\|pdf | Admin, Super Admin if enabled | Filters / downloadable file | Validate format and authorization; avoid unnecessary patient-level data. |

## Workflows and integrity
- State transitions: reports are read-only; export lifecycle/retention unspecified.
- Validation and database constraints: validate date ranges and allowed formats; aggregation must use consistent source filters.
- Transaction boundaries: use a consistent read snapshot where report consistency requires it.
- Audit events: report export/access metadata may be required; never log report contents or PHI.

## UI behavior
- Pages/forms: Admin dashboard with date filters, aggregates, and CSV/PDF export.
- API operations: report queries and authorized export.
- Error and empty states: invalid date range, empty result, and unavailable export format.

## Acceptance tests
- Given a non-admin role, when a report is requested, then access is denied.
- Given source records for an approved reporting period, when daily revenue is requested, then aggregation follows the approved payment rules.
- Given an authorized Admin exports CSV/PDF, when the export is generated, then only approved report fields are present.

## Open questions
- [ ] Finance/BA: define revenue basis (billed vs collected), timezone/day boundary, refunds, partial payments, and currency.
- [ ] Clinical/BA: define “patients seen” (completed appointment, unique patient, encounter) and deduplication.
- [ ] BA: define top-department metric, date filter defaults, and tie handling.
- [ ] Product/Security: confirm Super Admin, row-level export contents, report retention, and PDF/CSV implementation priority.
