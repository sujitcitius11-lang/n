# Pharmacy and inventory contract

## Source and status
- BRD/source: Medicines & Pharmacy Stock table and sections 3-4, 5.7, 7, 9.
- Reviewed by/date: Sliced from user-provided BRD on 2026-10-08.
- Status: draft; open questions below require decisions.

## Scope
- Goal: manage medicine/consumable stock and dispense medicines from prescriptions.
- In scope: medicine catalogue and stock visibility/update; prescription-based dispensing.
- Out of scope: procurement, supplier management, batch tracking, and billing linkage unless approved.

## Roles and permissions
| Role | Allowed actions | Restrictions |
|---|---|---|
| Pharmacist | Dispense prescribed medicines; manage stock | Exact adjustment/dispensing permissions and approval controls unspecified. |
| Admin | Manage pharmacy and inventory | Scope versus Pharmacist permissions unspecified. |
| Doctor | Create prescriptions | No stock adjustment or dispense access specified. |
| Patient | No inventory write permission specified | Prescription view is defined in prescriptions contract. |

## Data contract
| Entity/field | Type/constraints | Sensitivity | Source |
|---|---|---|---|
| Medicine.medicine_id | UUID, unique ID | Inventory identifier | BRD 6.9 |
| Medicine.name | String | Business data | BRD 6.9 |
| quantity_available | Integer stock count | Inventory data | BRD 6.9 |
| expiry_date | Date | Inventory/safety data | BRD 6.9 |
| unit_price | Decimal | Financial data | BRD 6.9 |
| Dispense/stock movement | Not modeled in BRD; required details unresolved | Patient and inventory data | BRD 5.7 |

## API contract
| Method/path | Role | Request/response | Behavior |
|---|---|---|---|
| POST /medicines | Pharmacist, Admin | Name, expiry, price, initial stock / medicine | Validate required inventory fields and audit creation. |
| GET /medicines | Pharmacist, Admin; Doctor lookup TBD | Filters / stock list | Restrict fields and roles according to approved policy. |
| PATCH /medicines/{medicine_id} | Pharmacist, Admin | Approved catalogue fields / medicine | Do not permit arbitrary stock change without a stock movement record. |
| POST /prescriptions/{prescription_id}/dispensations | Pharmacist | Selected prescribed medicines and quantities / dispense record | Verify prescription and atomically decrement eligible stock. |

## Workflows and integrity
- State transitions: dispense/partial dispense/return/adjustment are not specified.
- Validation and database constraints: nonnegative quantity, valid expiry, decimal price, and concurrent stock protection.
- Transaction boundaries: dispensing record and inventory decrement must commit or roll back together.
- Audit events: stock receipt/adjustment, dispense, and correction with actor and resource IDs only.
- FEFO/expiry handling and medicine substitution must not be assumed.

## UI behavior
- Pages/forms: Pharmacist inventory list/detail/adjustment and prescription dispensing.
- API operations: catalogue reads/writes and dispensing.
- Error and empty states: insufficient/expired stock, missing prescription, already-dispensed item.

## Acceptance tests
- Given an active prescription and sufficient stock, when the Pharmacist dispenses a prescribed quantity, then stock decreases exactly once.
- Given insufficient stock, when dispense is attempted, then it fails without a partial stock decrement or dispense record.
- Given a medicine is expired, when dispensing is attempted, then it is blocked unless an explicit policy permits it.

## Open questions
- [ ] Pharmacy/BA: define medicine strength/form/unit, SKU, batch/lot, supplier, stock movement and adjustment entities.
- [ ] Pharmacy/Clinical: define partial fills, substitutions, returns, expiry policy, and whether expired stock is always prohibited.
- [ ] Finance: define unit-price history and linkage between dispensed items and invoices.
- [ ] BA/Security: define Admin versus Pharmacist stock permissions and whether Doctors can see stock availability.
