"""Check rule/action/convention references in Copilot customization files."""

from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
INSTRUCTIONS = ROOT / ".github" / "copilot-instructions.md"
CUSTOMIZATION_DIRS = (
    ROOT / ".github" / "agents",
    ROOT / ".github" / "prompts",
    ROOT / ".github" / "skills",
)
ID_PATTERN = re.compile(r"\b([RAC]\d{2})(?:\([A-Za-z0-9_-]+\))?\b")
RANGE_PATTERN = re.compile(r"\b([RAC])(\d{2})\s*-\s*([RAC])(\d{2})\b")
DEFINITION_PATTERN = re.compile(
    r"^\s*(?:-\s*)?([RAC]\d{2})(?:\s+\([A-Za-z0-9_-]+\))?:\s*\S",
    re.MULTILINE,
)


def defined_ids() -> set[str]:
    if not INSTRUCTIONS.is_file():
        raise FileNotFoundError(f"Missing instruction file: {INSTRUCTIONS}")
    return set(DEFINITION_PATTERN.findall(INSTRUCTIONS.read_text(encoding="utf-8")))


def customization_files():
    for directory in CUSTOMIZATION_DIRS:
        if directory.exists():
            yield from directory.rglob("*.md")


def references_in(text: str) -> set[str]:
    references = set(ID_PATTERN.findall(text))
    for prefix, first, end_prefix, last in RANGE_PATTERN.findall(text):
        if prefix != end_prefix:
            references.add(f"{prefix}{first}")
            references.add(f"{end_prefix}{last}")
            continue
        start, stop = int(first), int(last)
        if start > stop:
            references.add(f"{prefix}{first}")
            references.add(f"{end_prefix}{last}")
            continue
        references.update(f"{prefix}{number:02}" for number in range(start, stop + 1))
    return references


def main() -> int:
    definitions = defined_ids()
    errors: list[str] = []
    for file_path in customization_files():
        text = file_path.read_text(encoding="utf-8")
        for missing in sorted(references_in(text) - definitions):
            errors.append(f"{file_path.relative_to(ROOT)}: undefined ID {missing}")
    if errors:
        print("\n".join(errors), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, UnicodeError) as error:
        print(f"rule ID check failed: {error}", file=sys.stderr)
        raise SystemExit(2) from error
