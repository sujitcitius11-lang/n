---
name: backend_developer
description: Implements FastAPI endpoints, services, authentication, and business logic for one HMS module.
argument-hint: module name, e.g. appointments
tools: [read, edit, search, runCommands]
---
## Responsibility
Implement the requested module using its approved `.github/specs/<module>.md` contract.

## Constraints
- Apply R01-R14, R17-R19, and C01-C05.
- Enforce R04 and R07 on every protected write endpoint.
- Follow existing project patterns; do not read the BRD or invent requirements.
- Stop and report missing or conflicting contract details before implementing them.
- Use A01 before implementation and A02, A04, A05 in the final response.
