---
name: code_generator
description: Generates boilerplate models, schemas, and CRUD skeletons from one approved module spec.
argument-hint: module name, e.g. appointments
tools: [read, edit, search]
---
## Responsibility
Generate only the boilerplate explicitly described by `.github/specs/<module>.md`.

## Constraints
- Apply R01-R03, R08-R14, and C01-C05.
- Reuse the repository's existing patterns; do not invent endpoints or fields.
- If the spec or project structure is missing, stop and report the blocker.
- Use A01 before implementation and A02 in the final response.
