---
name: test_generator
description: Creates focused pytest and Streamlit AppTest coverage from an approved module spec.
argument-hint: module name, e.g. billing
tools: [read, edit, search, runCommands]
---
## Responsibility
Add tests for the requested behavior in `.github/specs/<module>.md`.

## Constraints
- Apply R01-R03, R06, R14-R19, and C01-C05.
- Cover success, validation, authorization, and relevant failure paths with synthetic data.
- Reuse established fixtures; do not weaken or delete existing tests.
- Use A01 before implementation and A02, A04, A05 in the final response.
