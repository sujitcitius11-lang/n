# Validation hooks

The repository does not currently have a Git repository or application dependencies, so no local hook was installed. VS Code agent hooks are preview/harness-specific; Copilot Agent Host and Local use different event schemas. Do not enable an unverified tool-blocking hook.

For the portable fallback, install `pre-commit` in the developer environment and run `pre-commit install` after this folder is inside a Git repository. The checked-in `.pre-commit-config.yaml` runs the rule-ID checker, Ruff, and the test suite at commit time. Install the project dependencies first.

The rule-ID checker scans only `.github/agents`, `.github/prompts`, and `.github/skills`; it does not read virtual environments, build output, data, logs, or application files.
