---
name: audit-logging
description: Record auditable HMS writes without capturing patient data or secrets.
---
# Audit logging

1. Use the existing audit service/dependency and event vocabulary; first inspect its implementation.
2. Emit an audit event for each successful create, update, or delete operation required by the contract.
3. Include only necessary actor, action, resource identifier, and timestamp metadata.
4. Never include request/response bodies, clinical details, passwords, tokens, or secrets.
5. Keep audit persistence consistent with the business transaction when the design requires atomicity.
6. Test that expected events are recorded and sensitive values are absent.
7. If no audit mechanism or retention policy exists, report the gap rather than inventing one.
