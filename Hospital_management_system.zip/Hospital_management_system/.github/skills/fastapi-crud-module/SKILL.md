---
name: fastapi-crud-module
description: Implement a single FastAPI CRUD module from its approved HMS contract.
---
# FastAPI CRUD module

1. Read the module spec and inspect nearby router, service, schema, and persistence patterns.
2. Keep route handlers thin; put business rules in services and persistence in the established repository/session layer.
3. Define Pydantic v2 request and response schemas separately from SQLAlchemy models.
4. Enforce authentication, role authorization, record scoping, and audit behavior on writes.
5. Use explicit transactions and constraints for multi-step or integrity-sensitive operations.
6. Add tests for success, validation, missing records, forbidden access, and rollback where applicable.
7. Follow the global HMS instructions; stop on a missing contract decision instead of guessing.
