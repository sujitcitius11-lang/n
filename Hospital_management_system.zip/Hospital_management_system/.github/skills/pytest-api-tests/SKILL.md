---
name: pytest-api-tests
description: Create focused pytest coverage for FastAPI endpoints with safe test data and auth fixtures.
---
# API tests

1. Reuse existing app, database, and authentication fixtures; do not build a second test harness.
2. Use synthetic data only and isolate database state between tests.
3. Cover success, validation, not-found, unauthorized/forbidden, and relevant transaction failures.
4. Assert response shape and persistent effects without depending on incidental implementation details.
5. Include role and record-ownership boundaries for protected resources and write endpoints.
6. Keep tests deterministic; avoid external services and real patient records.
7. Run focused tests first with `pytest -q -x` and report exact validation performed.
