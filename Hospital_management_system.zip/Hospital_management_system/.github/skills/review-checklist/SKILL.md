---
name: review-checklist
description: Review HMS diffs for correctness, privacy, authorization, data integrity, and test gaps.
---
# HMS review checklist

Review only the requested diff and its relevant context. Report findings, not speculative advice.

- Do protected routes enforce the specified role and resource ownership?
- Are writes audited without PHI, credentials, or secrets?
- Are validation, errors, transaction boundaries, and database constraints correct?
- Does Streamlit use only the HTTP API and avoid exposing patient data?
- Are queries efficient and scoped, with no obvious N+1 behavior?
- Do tests cover success, denied access, validation, and important failure paths?
- Include severity, file/line, concise evidence, and validation gaps; do not edit files.
