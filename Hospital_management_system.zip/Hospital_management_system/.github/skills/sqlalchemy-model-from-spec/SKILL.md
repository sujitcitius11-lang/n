---
name: sqlalchemy-model-from-spec
description: Translate approved HMS data contracts into SQLAlchemy 2 models and Alembic migrations.
---
# SQLAlchemy model from spec

1. Map only fields and relationships present in the approved module contract.
2. Use SQLAlchemy 2 typed mappings and UUID primary keys for new entities unless the spec says otherwise.
3. Encode nullability, uniqueness, foreign keys, indexes, and checks in the database where appropriate.
4. Keep types portable between PostgreSQL and local SQLite; isolate PostgreSQL-only features explicitly.
5. Add an Alembic migration for schema changes; do not create production tables on application startup.
6. Test constraints, relationship behavior, and transaction boundaries against the project's supported test database.
7. Never place PHI or credentials in migration fixtures or defaults.
