---
name: streamlit-page
description: Build a Streamlit workflow that uses the shared HMS API client and safe session state.
---
# Streamlit page

1. Follow the existing page navigation, layout, and shared API-client patterns.
2. Call FastAPI over HTTP; never import database sessions, ORM models, or repositories.
3. Validate user input for usability, while treating server-side validation and authorization as authoritative.
4. Handle API errors, loading, empty, and success states explicitly without leaking internal details.
5. Keep patient data out of URLs, logs, and persistent session state unless the contract requires it.
6. Add Streamlit `AppTest` coverage for key interactions and error states.
7. Implement only workflows described in the approved module spec.
