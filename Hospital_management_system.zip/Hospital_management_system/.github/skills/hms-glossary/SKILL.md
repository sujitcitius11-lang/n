---
name: hms-glossary
description: Keep HMS module terminology consistent and flag undefined domain terms for confirmation.
---
# HMS glossary

- **Patient**: person receiving care; use the term and identifier defined by the approved contract.
- **Appointment**: scheduled encounter between a patient and care provider; lifecycle states are contract-defined.
- **Provider**: clinician or other care professional; do not assume this means every staff role.
- **Department**: organizational unit; membership and assignment rules are contract-defined.
- **Prescription**: medication order; clinical fields and status transitions must come from the BRD-derived spec.
- **Lab order/result**: requested test and its result; access and visibility are role- and contract-defined.
- **Billing**: charges and payments; preserve transaction integrity and never assume accounting rules.
- Flag ambiguous or conflicting terms as open questions; do not silently normalize domain behavior.
