---
name: jwt-rbac
description: Apply the HMS JWT, password-hashing, and role authorization contract safely.
---
# JWT and role-based access

1. Reuse the shared authentication and authorization dependencies; do not create a parallel policy path.
2. Hash passwords with bcrypt and compare hashes through the project's password utility.
3. Validate JWT signature, expiry, issuer/audience where configured, and required identity/role claims.
4. Apply deny-by-default role checks at every protected API operation; scope records to the authorized principal.
5. Keep tokens, passwords, and sensitive claims out of logs, URLs, and error messages.
6. Test allowed roles, denied roles, invalid/expired tokens, and object-level access boundaries.
7. Do not invent role permissions absent from the approved module spec.
