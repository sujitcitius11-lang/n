# HMS Copilot customizations

## Workflow

1. Review and approve the draft module contracts under `specs/`; resolve their open questions before implementation.
2. Start one module per session using `/generate_module`, `/generate_frontend`, and `/generate_tests` as needed.
3. Run `/review_diff` before merging. Agents use the global requirements in `copilot-instructions.md`.
4. Install the pre-commit tool after the application environment and Git repository are ready: `pre-commit install`.

## Compatibility notes

- Workspace agents live in `agents/`; on-demand skills live in `skills/`. These paths follow VS Code's Copilot customization layout.
- Prompt files are retained under `prompts/` for Local-agent compatibility. Current VS Code documentation marks prompt files deprecated and says Agent Host sessions do not load them; use the corresponding custom agent and skill in Agent Host sessions.
- Agent `model` frontmatter is intentionally omitted because the suggested Claude model names are not Copilot model IDs. Select a suitable model in the VS Code model picker.
- VS Code hooks are preview and harness-specific. The pre-commit configuration is the supported fallback here; see `hooks/README.md` before enabling event hooks.

## Repository status

The BRD was supplied in chat after the customization set was created and has now been sliced into draft module contracts. The workspace still has no application code or dependency manifest, so no application tests or hook installation have been performed. The BRD describes Java/Spring Boot and Angular/React, while the selected implementation stack is FastAPI/Streamlit; this needs explicit confirmation.
