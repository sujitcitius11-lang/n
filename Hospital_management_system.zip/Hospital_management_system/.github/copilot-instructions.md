# HMS Global Instructions

Legend: R = rules (must/never), A = actions (procedures/output), C = conventions.
Rule IDs are stable: never renumber or reuse a retired ID; mark retired entries `[removed]`.

## Stack and architecture

### Conventions

- C01: Backend uses FastAPI, Pydantic v2, SQLAlchemy 2, and Alembic.
- C02: Streamlit is the UI and communicates with FastAPI over HTTP using `httpx`; it never connects to the database.
- C03: PostgreSQL is the production database. SQLite is allowed for local development and tests when behavior remains portable.
- C04: Keep API routers, business services, persistence models, schemas, and UI pages in their established layers; inspect the repository before adding new structure.
- C05: Use `pytest`, FastAPI `TestClient`, Streamlit `AppTest`, and Ruff for validation.

## Security and privacy

- R01: For implementation work, use the requested `.github/specs/<module>.md` contract; do not read the full BRD. Only `spec_slicer` may read the BRD.
- R02: Do not invent product requirements or silently change a module contract. Surface gaps or conflicts before implementing affected behavior.
- R03: Validate and authorize requests at the server boundary; never trust UI-side validation or hidden controls as security.
- R04 (RBAC): Enforce the specified role on every protected endpoint through the shared FastAPI role dependency. Deny access by default.
- R05 (credentials): Use JWT authentication and bcrypt password hashing; never store or return plaintext passwords.
- R06 (privacy): Never log or expose patient health information, credentials, access tokens, or secrets. Use synthetic test data.
- R07 (audit): Audit every data-changing operation using the project-standard audit mechanism; do not record PHI or secrets in audit details.
- R08: Read secrets from environment/configuration; do not commit real credentials or use insecure production defaults.

## API and database

- R09: Use UUID primary keys for new entities unless the existing contract explicitly requires another type.
- R10: Define SQLAlchemy 2 models and Pydantic v2 schemas; keep persistence models separate from API response schemas.
- R11: Manage schema changes with Alembic migrations; do not rely on runtime table creation in production.
- R12: Use database constraints and transactions for integrity-sensitive workflows, including billing and appointment booking.
- R13: Keep queries parameterized and scoped to the caller's authorized records; avoid N+1 query patterns.
- R14: Return explicit, safe API errors. Do not swallow exceptions, expose internal details, or return success-shaped fallbacks.

## Streamlit

- R15: Streamlit pages call the FastAPI client only; do not import database sessions, ORM models, or repositories into UI code.
- R16: Keep patient data out of URLs, browser-facing logs, debug output, and persistent session state unless the contract requires it.

## Testing and changes

- R17: Add or update focused tests for each behavior change, including authorization and failure paths for protected writes.
- R18: Do not weaken or delete an existing test to make a change pass; explain any unavoidable test limitation.
- R19: Preserve established behavior outside the requested change and report unresolved assumptions explicitly.

## Actions

- A01: Start implementation with a plan of no more than five bullets, then make the changes.
- A02: Finish with changed file paths and a summary of no more than five lines.
- A03: Edit in place; do not paste or regenerate whole files when a focused edit is sufficient.
- A04: For changed Python files, run Ruff check and format on those files; run focused tests with `pytest -q -x`.
- A05: Report the validation commands and whether they passed; never claim a check ran if it did not.
- A06: For review requests, inspect only the requested diff and report findings without editing files.
