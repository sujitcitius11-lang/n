---
name: generate_frontend
description: Implement one Streamlit module page using the shared API client.
agent: frontend_developer
argument-hint: module name, e.g. patients
---
Module: ${input:module:patients}
Spec: `.github/specs/${input:module:patients}.md`
Implement only the specified UI workflow and call FastAPI through the shared HTTP client.
Apply R01-R03, R06, R14-R19, C01-C05, and A01-A05.
