# Prompt files

These prompts are kept under the supported workspace path `.github/prompts/`. Per current VS Code documentation, prompt files are deprecated and are not loaded in Agent Host sessions; use them with the Local agent only. The named custom agents and on-demand skills are the supported alternatives for Agent Host.

Prompts reference rule IDs from `../copilot-instructions.md`. Run `python .github/scripts/check_rule_ids.py` after editing customization files.
