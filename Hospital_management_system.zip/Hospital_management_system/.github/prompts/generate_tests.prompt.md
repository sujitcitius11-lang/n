---
name: generate_tests
description: Add focused API and Streamlit tests for one HMS module.
agent: test_generator
argument-hint: module name, e.g. billing
---
Module: ${input:module:billing}
Spec: `.github/specs/${input:module:billing}.md`
Add focused tests for the specified behavior, including applicable authorization and failure cases.
Use synthetic patient data; apply R01-R03, R06, R14-R19, C01-C05, and A01-A05.
