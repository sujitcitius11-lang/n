---
name: generate_module
description: Implement one backend HMS module from its approved contract.
agent: backend_developer
argument-hint: module name, e.g. appointments
---
Module: ${input:module:appointments}
Spec: `.github/specs/${input:module:appointments}.md`
Implement only this module's backend contract and preserve existing behavior.
Apply R01-R14, R17-R19, C01-C05, and A01-A05.
