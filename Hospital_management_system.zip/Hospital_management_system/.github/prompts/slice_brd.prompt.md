---
name: slice_brd
description: Convert a supplied BRD into small, traceable module contracts.
agent: spec_slicer
argument-hint: BRD file path and optional module list
---
BRD: ${input:brdPath:path/to/BRD.md}
Modules: ${input:modules:Auth, Patients, Doctors/Departments, Appointments, Prescriptions, Lab, Billing, Pharmacy, Reports}
Create 40-80 line contracts in `.github/specs/`, using `.github/specs/TEMPLATE.md`.
Preserve source-backed requirements and list unresolved questions rather than guessing.
Apply R02, R06, R08-R19, C01-C05, A01, and A02.
