---
name: review_diff
description: Review the current change for bugs and HMS-specific risks without editing.
agent: code_reviewer
argument-hint: optional scope or module name
---
Review only the current diff and directly relevant test output; do not edit files.
Prioritize concrete findings with severity, file, line, and evidence.
Apply A06, R02-R19, and C01-C05; finish with validation gaps, if any.
