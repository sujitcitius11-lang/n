# Healthcare PHI De-Identification Studio — Complete Project Explanation

**Contents**

1. The use case (the problem we solve)
2. The project in one page
3. Technologies used — and why
4. Architecture and a worked example
5. Code explanation, file by file
6. Evaluation (how we know it works)
7. Conclusion
8. Limitations and future scope
9. Questions and answers
10. Speaking script

---

# 1. The Use Case

## 1.1 Scenario

Riverside Regional Hospital's outcomes-research office agreed to share a multi-year corpus of **Emergency Department clinical notes** with a university partner. The partner studies how *treatment timing affects patient outcomes*.

The data-use agreement is **non-negotiable**. Before a single file leaves the hospital network, every note must be de-identified to the **HIPAA Safe Harbor** standard. That means no:

- patient names
- dates
- locations
- phone numbers
- medical record numbers (MRNs)
- provider / organisation names

## 1.2 Why it is hard today

| Today | Consequence |
|---|---|
| A small compliance team reads every note and redacts by hand, a few minutes per note | Fine for occasional requests |
| This study needs **tens of thousands** of notes | **Months** of reading before the partner can even start; the team has other duties |

## 1.3 Why the data is messy

| Property of the data | Why it hurts |
|---|---|
| About ¾ of notes were typed in the current EHR; about ¼ are older **scanned** notes passed through OCR | OCR creates its own errors (`Jo hn`, `OO4521`) that typed notes don't have |
| Many **date formats**: `03/03/2026`, `March 3, 2026`, `3-3-26`, `2026-03-03` | NER misses two-digit-year and dash-separated dates more often |
| EHR **copy-forward**: a new note starts by quoting the prior visit in full | One patient's name appears 2–3 times in what looks like one note |
| PDF-to-text **line breaks** (`John\nMiller`) | A name split across lines is often not recognised as one PERSON |
| **Hospital-specific names** (`Riverside East Wing`, `the Comm. Health annex`) | A general model was never trained on them |
| **MRNs and phone numbers** | They are not "named entities" in the linguistic sense, so NER cannot find them |

## 1.4 The agreed plan

The compliance office is **not removing the human reviewer**. If identifying information slips through, the consequences are serious. Instead:

1. An automated spaCy-based pass produces a **first-draft redaction** of every note.
2. The compliance team's job shifts from *redacting from scratch* to *spot-checking and correcting the draft*, which is much faster.

## 1.5 Why Named Entity Recognition (NER)?

This is **not a classification problem**. Nothing is labelled "Category A vs. Category B". The task is to **locate and extract specific spans of text** (a name, a date, a place) inside free-flowing narrative. NER does exactly that: it tags spans as `PERSON`, `DATE`, `GPE` (location) or `ORG`, and those spans can then be replaced by placeholders such as `[PATIENT]` or `[DATE]`.

Bag-of-Words or Naive Bayes would only tell us *"this note contains PHI"*. They could not tell us *where*, so they could not redact anything.

General-purpose NER alone is **not enough**. MRNs and phone numbers aren't named entities. That is why the cleaning steps lean on **regex working alongside NER, not instead of it**.

## 1.6 What "success" means (the goal we must meet)

| Requirement from the use case | Where we meet it |
|---|---|
| Regex pre-pass for MRN, phone, e-mail, structured DOB | `regex_processor.py` |
| Normalise inconsistent date formats before relying on spaCy | `date_normalizer.py` |
| Strip nested copy-forward text before NER | `copy_forward.py` |
| OCR correction **only** for the scanned batch | `ocr_corrector.py` |
| Standardise whitespace and line-wrap artifacts | `whitespace_cleaner.py` |
| Custom facility dictionary to supplement ORG | `ner_redactor.py` + `facility_dictionary.pkl` |
| Verification scan against the patient's real identifiers | `verifier.py` |
| First-draft redaction shifts work to spot-checking | Batch + Review Queue tabs |
| Verification is mandatory, not optional | Built into every pipeline run |
| Edge cases are logged and grow a dictionary / custom NER | `logs/edge_cases.csv` + "Teach the system" |

---

# 2. The Project in One Page

**What it is.** A Python system that takes a clinical note in almost any format (TXT, CSV, JSON, PDF, DOCX, or an image), removes all HIPAA Safe Harbor identifiers, checks that they are really gone, records everything in an audit log, and presents the result in an interactive dashboard for a human reviewer.

**How it works, in one sentence.** Structured PHI (MRN, phone, e-mail, DOB) is removed by **regex**, the text is cleaned (dates, copy-forward, whitespace, OCR), **spaCy NER plus a facility dictionary** removes names, dates, places and organisations, and a **verification scan** searches the result for the patient's *actual* identifiers.

**What is distinctive.**

- Regex and NER **cooperate**, each doing what it is best at.
- Verification is checked against **ground-truth EHR fields**, not against what NER happened to flag.
- The cleaning steps are **scoped** (OCR fixes only on scanned notes).
- Quality is **measured**: recall per identifier, ablation study, a live self-check of all seven requirements.
- A **human-in-the-loop** review queue is part of the product.

**Layers of the code.**

```
Presentation   streamlitmain.py            (dashboard, all interactivity)
Visualisation  utils/visuals.py            (Plotly charts, HTML helpers)
Services       services/pipeline_service   (orchestration)
               services/evaluation_service (metrics, ablation, self-check)
Processors     processors/*                (one class per cleaning/redaction step)
Utilities      utils/audit_logger.py       (audit trail)
Resources      models/*.pkl, config.py, data/*.csv
```

---

# 3. Technologies Used — and Why

| Technology | Role in the project | Why we chose it |
|---|---|---|
| **Python 3** | Everything | The standard language for NLP; the best ecosystem for text, data and dashboards. |
| **spaCy** (`en_core_web_sm`) | Named Entity Recognition | Fast, runs on a CPU, works **offline** (PHI must never be sent to an external API), easy to extend with custom rules. The small model is enough for a first draft. |
| **Regular expressions (`re`)** | MRN, phone, e-mail, DOB, SSN, dates, copy-forward, whitespace | Structured PHI follows exact patterns, so regex is more reliable and more transparent than a statistical model. It is also deterministic and auditable. |
| **python-dateutil** | Parsing many date styles into one | Understands `3-3-26` and `March 3, 2026` without writing a parser per format. |
| **Pickle (`.pkl`)** | Stores the facility dictionary and OCR rules | Resources are separated from code, so a compliance officer can grow the dictionary without touching the logic. |
| **pandas** | Datasets, results tables, audit log | The natural tool for tabular records and CSV I/O. |
| **PyPDF2** | Read text from PDFs | Lightweight, pure-Python. |
| **python-docx** | Read DOCX (paragraphs and tables) | Clinical documents often arrive as Word files; tables can also contain PHI. |
| **Pillow + pytesseract (Tesseract OCR)** | Read text from images | Free, local OCR, so images never leave the machine. |
| **Streamlit** | Interactive dashboard | Turns Python into a web app quickly, with widgets (upload, tabs, download) built in. |
| **Plotly** | Interactive charts (donut, radar, heatmap, sunburst, gauges) | Hover, zoom and colour make the evaluation understandable to non-programmers. |
| **matplotlib** | Static EDA charts saved as PNG | Simple, produces report images. |
| **openpyxl** | Excel export | Compliance teams live in Excel. |
| **pytest** | Automated tests | Guards against regressions in a compliance tool. |
| **CSV audit logs** | Traceability | Open format, easy to hand to an auditor. |

**A design principle behind the choices:** everything runs **locally and offline**. That is a deliberate privacy decision, not a convenience.

---

# 4. Architecture and a Worked Example

## 4.1 Pipeline

```
Input file (TXT · CSV · JSON · PDF · DOCX · PNG · JPG · TIFF · BMP)
   │  FileReader (+ Tesseract OCR for images)
   ▼
 1. Regex pre-pass ........ MRN · phone · e-mail · DOB · SSN
 2. Date normalization .... every date variant  →  YYYY-MM-DD
 3. Copy-forward removal .. drop quoted prior notes
 4. Whitespace cleaning ... re-join line-wrapped names/dates
 5. OCR correction ........ only if the note is flagged scanned
 6. spaCy NER + dictionary  PERSON · DATE · GPE · ORG · facilities
   ▼
 7. Verification scan ..... search output for the patient's REAL identifiers
 8. Audit log ............. logs/audit_log.csv (+ edge_cases.csv on FAIL)
   ▼
 Human review queue → approved, shareable notes
```

## 4.2 Why this order?

| Rule | Reason |
|---|---|
| Regex **before** NER | Structured PHI is removed before free text reaches spaCy; NER was never trained to recognise an MRN. |
| Dates normalised **before** NER | The four date forms become one canonical form so a reviewer can confirm every variant was caught. |
| Copy-forward stripped **before** NER | Otherwise the same name survives at a second nesting level. |
| Whitespace fixed **before** NER | Entity-span detection is sensitive to a name broken across a line break. |
| OCR fixes **only** for scanned notes | Applying them to natively typed notes would introduce new errors where none exist. |
| Verification **last**, on the final output | It is the safety net for everything above. |

## 4.3 Worked example (the note from the use-case document)

**Raw scanned note** (patient John Miller, MRN 004521, DOB 1985-03-03):

```
Jo hn Miller (MRN: OO4521) seen 3-3-26 at Riverside East Wing. Patient reports
chest tightness since yesterday. Contact: (555) 019-2231, jmiller82@email.com.
DOB: 1985-03-03.
```

| Step | Text after the step |
|---|---|
| 1. Regex | `Jo hn Miller ([MRN]) seen 3-3-26 at Riverside East Wing. … Contact: [PHONE], [EMAIL]. [DOB].` |
| 2. Dates | `… seen 2026-03-03 at Riverside East Wing …` |
| 3. Copy-forward | *(nothing to remove)* |
| 4. Whitespace | *(already clean)* |
| 5. OCR (scanned) | `John Miller ([MRN]) seen 2026-03-03 …`  ← `Jo hn` fixed |
| 6. NER + dictionary | `[PERSON] ([MRN]) seen [DATE] at [ORG]. … since yesterday. Contact: [PHONE], [EMAIL]. [DOB].` |
| 7. Verification | Searches for "John", "Miller", "004521", "1985-03-03", phone, e-mail, facility → **PASS** |

Notice that "yesterday" and "2 weeks" are **kept**. They are not identifiers, and keeping them preserves research value.

---

# 5. Code Explanation, File by File

Files are explained in the order the data flows through them.

## 5.1 `config.py` — central settings

Holds constants used across the project:

- `DATASET_PATH`, `FACILITY_MODEL_PATH`, `OCR_RULES_PATH`, `AUDIT_LOG_PATH`, `OUTPUT_FOLDER` — your original paths.
- Added: `EDGE_CASE_LOG_PATH`, `REPORTS_FOLDER`, `CHARTS_FOLDER`, `TESSERACT_CMD` (optional override), `SUPPORTED_FORMATS`.
- `PHI_COLORS` — one colour per PHI type, used by every chart and highlight so the dashboard is visually consistent.
- `TARGET_IDENTIFIER_RECALL = 0.99` — the quality bar shown on the evaluation charts.

**Why:** one place to change a path or a target, instead of hunting through files.

## 5.2 `create_pickle_files.py` — builds the model resources

Creates `models/facility_dictionary.pkl` (list of hospital-specific names: Riverside East Wing, Comm. Health annex, Riverside Regional, ED Triage Unit) and `models/ocr_rules.pkl` (dict of wrong → correct, e.g. `Jo hn → John`, `OO → 00`).

**Why pickle:** the dictionary and rules are *data*, not logic. They can grow (see the Review Queue's "Teach the system") without editing code. Run once before first use.

## 5.3 `create_sample_data.py` — synthetic datasets

Writes `data/sample_notes.csv` (5 notes: 2 scanned, 3 native, 2 facilities, with copy-forward, line breaks, OCR errors and multiple date formats) and `data/edge_case_notes.csv` (3 harder notes with a nickname, a variant facility spelling and an abbreviation).

**Why synthetic:** real PHI cannot be used for development. The columns mirror an EHR export: `note_id, patient_name, mrn, dob, phone, email, facility, is_scanned, note_text`.

## 5.4 `processors/file_reader.py` — `FileReader`

Turns any supported file into plain text.

- `read_file(path)` looks at the extension and routes to `_read_txt`, `_read_csv`, `_read_json`, `_read_pdf`, `_read_docx` or `_read_image`. Unknown extensions raise `ValueError`.
- `_read_image` converts to grayscale and runs Tesseract with `--psm 6` (treat the page as one uniform block of text).
- `_read_docx` reads paragraphs **and tables**, because PHI can sit in a table cell.
- `read_csv_records` keeps the structured columns (used by batch mode).
- `_configure_tesseract()` finds the Tesseract binary via config, environment variable, `PATH`, or your original Windows path, so the code runs on any machine.

## 5.5 `processors/regex_processor.py` — `RegexProcessor` (stage 1)

Removes **structured** PHI that NER cannot see.

| Pattern | Catches | Placeholder |
|---|---|---|
| MRN | `MRN: 004521`, `MRN 004521`, `MRN#004521` | `[MRN]` |
| DOB | `DOB: 03/03/1985`, `DOB: March 3, 1985` | `[DOB]` |
| E-mail | `name@domain.com` | `[EMAIL]` |
| SSN | `123-45-6789` | `[SSN]` |
| Phone | `(555) 019-2231`, `555-019-2231`, `555.019.2231`, `+1 555…`, `5550192231` | `[PHONE]` |

Key points:

- Rules run in a deliberate order (MRN and DOB first) so a 10-digit MRN is never mistaken for a phone number.
- `process(text)` returns `clean_text`, `redaction_counts` (per type) and `matches` (what exactly was found, used for the dashboard's entity table).

## 5.6 `processors/date_normalizer.py` — `DateNormalizer` (stage 2)

Converts every written date style to `YYYY-MM-DD`.

- Four patterns (ISO, slash, dash, month-name) plus day-first (`17 Aug 26`) are joined into one combined regex.
- For each match, `dateutil.parser.parse()` produces the canonical date; if parsing fails, the text is left unchanged.
- `normalize_with_report()` also returns *what changed*, which the dashboard shows in the pipeline trace.
- `normalize_text()` keeps your original interface.

**Why single-pass `re.sub`:** the original loop used `text.replace()` per match, which could double-replace overlapping text.

## 5.7 `processors/copy_forward.py` — `CopyForwardRemover` (stage 3)

Removes prior-visit text quoted at the start of a note.

- Block markers `Copy-forward note:`, `Copied note:`, `Forwarded note:` run until `New visit:`, a blank line, or end of text. Stopping at the blank line means the new clinical content is not accidentally deleted when there is no "New visit:" marker.
- A second pattern removes long quoted strings (20+ characters in single quotes), with look-arounds so ordinary apostrophes ("the patient's … the doctor's") are **not** treated as quotes.

## 5.8 `processors/whitespace_cleaner.py` — `WhitespaceCleaner` (stage 4)

- Re-joins hyphenated line wraps (`Mil-\nler` → `Miller`).
- Converts newlines and tabs to spaces.
- Collapses runs of whitespace.

**Why:** `John\nMiller` is frequently *not* recognised as one PERSON span. Restoring continuous text raises NER accuracy.

## 5.9 `processors/ocr_corrector.py` — `OCRCorrector` (stage 5)

Loads `ocr_rules.pkl` and fixes OCR misrecognitions **only if `is_scanned` is true**.

- Letter-confusion rules like `OO → 00` are applied **only inside tokens that already contain a digit** (`OO4521`). So the word "Good" is never turned into "G00d".
- Other rules (`Jo hn → John`) are direct replacements.
- `correct_with_report()` returns which rules fired.

**Why scoped:** the use case states applying the same correction to natively typed notes "would introduce new errors where none exist".

## 5.10 `processors/ner_redactor.py` — `NERRedactor` (stage 6)

The heart of the system.

1. **Loads** `en_core_web_sm` and the facility dictionary.
2. **Collects candidates** from three sources:
   - **spaCy** entities: `PERSON → [PERSON]`, `DATE → [DATE]`, `ORG → [ORG]`, `GPE → [LOCATION]`
   - a **regex safety-net** for ISO dates (`2026-03-03`), because spaCy's DATE label is known to miss some styles
   - the **facility dictionary** (case-insensitive match)
3. **Filters false positives:**
   - skips anything overlapping an existing `[PLACEHOLDER]` (this fixed a `[[ORG]]` bug)
   - skips clinical abbreviations (ECG, ED, MRI…) that spaCy mistakes for organisations
   - skips relative dates ("yesterday", "3 days ago") which are not identifiers
4. **Resolves overlaps** greedily: priority *dictionary > regex > spaCy*, then longest span.
5. **Replaces from the end of the string backwards** so earlier character offsets stay valid.
6. Returns `redacted_text`, `entities_found`, a per-label `breakdown`, and the list of `entities` with their source.

## 5.11 `processors/verifier.py` — `Verifier` (stage 7)

The mandatory safety net. Given the redacted text and the patient's **real** identifiers from structured EHR fields, it searches for:

| Check | How |
|---|---|
| Full name | Case-insensitive search |
| Each name part ("Miller" alone) | Word-boundary search, parts of 3+ letters |
| MRN | Exact and without the "MRN" prefix |
| DOB | In many written formats (`1985-03-03`, `03/03/1985`, `3-3-85`, `March 3, 1985` …) |
| Phone | Digits only, ignoring punctuation |
| E-mail | Case-insensitive |
| Facility | Ignoring case and punctuation (`Comm. Health annex` = `comm health annex`) |

Returns `status` (`PASS`/`FAIL`), `issues`, a `checks` table, `checks_performed` and `verified`. If nothing was supplied to check, `verified` is False so the UI can warn rather than show a false "100%".

## 5.12 `utils/audit_logger.py` — `AuditLogger`

Append-only audit trail in `logs/audit_log.csv`: timestamp, note id, file name, entity count, verification status, scanned flag, processing time, issues.

- Failed notes are *also* written to `logs/edge_cases.csv` — the raw material for a bigger dictionary or a custom NER model.
- Automatically **migrates** an old, narrower log file to the new columns.
- Helpers: `read_log()`, `read_edge_cases()`, `clear()`.

## 5.13 `services/pipeline_service.py` — `PHIDeidentificationPipeline`

The orchestrator that connects all processors.

- `__init__` creates one instance of each processor plus the logger.
- `process_text(text, is_scanned, metadata, …, disabled)` runs the whole pipeline and returns a **trace**: per-stage before/after text, timing and details, the entities, the verification result and total time. `disabled` lets a stage be skipped, which powers the ablation study.
- `process_record(row)` processes a dataset row; it keeps your original output keys.
- `process_dataset(path_or_dataframe)` processes a whole corpus, saves `data/output/redacted_notes.csv`, and can report progress.
- `load_dataset()` reads CSVs **as text**, so MRN `004521` doesn't become `4521`.

## 5.14 `services/evaluation_service.py`

Turns traces into measurable quality.

- `identifier_matrix` — for each note and identifier: `removed`, `LEAKED`, or `n/a` (identifier never appeared in the text). Comparison ignores spaces and punctuation, so `Jo hn Miller` counts as a leak of `John Miller`.
- `recall_by_type`, `overall_recall` — share of identifiers removed.
- `utility_retention`, `note_summary` — how much ordinary text is kept (over-redaction proxy).
- `source_contribution`, `entity_table`, `stage_latency`, `group_comparison` — detector contribution, entity lists, timing and scanned vs. native.
- `run_ablation` — switches each stage off in turn and re-scores the corpus.
- `date_format_coverage` — pushes eight date styles through the pipeline and checks each is caught.
- `run_self_check` — one executable test per each of the seven cleaning requirements.

## 5.15 `utils/visuals.py`

All Plotly figures (donut, stage-impact bars, gauges, recall bars, radar, heatmap, sunburst, scatter, ablation chart, timeline) and the HTML helpers (KPI cards, colour-coded highlighting of original and redacted text). Kept out of the main file so `streamlitmain.py` stays focused on interaction.

## 5.16 `streamlitmain.py` — the dashboard

**Setup.** Page config, custom CSS (gradient hero, KPI cards, styled tabs and sidebar), and `@st.cache_resource` so spaCy loads **once**, not on every click.

**State.** `st.session_state` remembers the latest result, batch, ablation and reviewer decisions. Processing is keyed by a *signature* of the input, options and metadata, so Streamlit's constant re-runs don't process or log the same note repeatedly.

**Sidebar.** Verification metadata (name, MRN, DOB, plus phone, e-mail, facility), OCR mode (Auto-detect / Scanned / Native), audit toggle, supported formats, colour legend.

**Seven tabs.**

| Tab | Function |
|---|---|
| 🛡️ Redact | Upload/paste/demo; KPIs; highlighted original vs. redacted; charts; verification table; stage-by-stage trace; downloads |
| 📦 Batch | Choose a dataset, run, see charts, filter, inspect a note, export CSV/JSON/Excel |
| 📊 Evaluation | Gauges, recall, radar, heatmap, scanned vs. native, latency, ablation, date coverage |
| 👩‍⚕️ Review Queue | Priority queue, reviewer decisions, export approved notes, add to dictionary, edge-case log |
| 🔎 EDA Explorer | Dataset health and a "dirty-data census" that justifies each cleaning step |
| 📋 Audit Log | Timeline, PASS/FAIL, filter, download, guarded clear |
| 🏗️ Architecture & Compliance | Pipeline diagram, live 7-requirement self-check, expected outcomes |

## 5.17 `main.py` and `eda.py`

- `main.py` — command-line run: processes a CSV, prints redacted notes and per-identifier recall, saves the output.
- `eda.py` — EDA: record counts, missing values, duplicates, scanned/non-scanned, facilities, text length and word count; grouping, sorting, filtering; writes `reports/eda_summary.txt`, `facility_summary.csv`, `eda_processed_dataset.csv` and charts.

## 5.18 Tests

- `tests/test_processors.py` — regex, date formats, copy-forward (including the apostrophe case), whitespace, OCR scoping, verifier cases.
- `tests/test_pipeline.py` — NER, no double-wrapped placeholders, dataset pass, edge cases flagged, MRN zeros kept, all seven requirements.
- `tests/test_audit_logger.py` — logging and edge-case logging.
- `test_copy_forward.py`, `test_audit_logger.py` (root) — your original quick demo scripts.

Result: **18 tests pass.**

## 5.19 Supporting files

- `requirements.txt` — dependencies (plus notes for the spaCy model and Tesseract).
- `.streamlit/config.toml` — theme colours and upload limit.
- `README.md` — project documentation.

---

# 6. Evaluation

## 6.1 Method

**Ground truth** is the patient's structured EHR fields (name, MRN, DOB, phone, e-mail, facility). For every identifier that actually appears in the original note, we test whether it survives in the redacted output.

| Metric | Meaning |
|---|---|
| **Identifier recall** | Identifiers removed ÷ identifiers present |
| **Verification pass rate** | Notes with zero leaks ÷ all notes |
| **Text retained** | Ordinary words kept ÷ original words (over-redaction proxy) |
| **Ablation** | Each stage switched off, corpus re-scored |
| **Date coverage** | Each date variant must end as `[DATE]` |
| **Requirement self-check** | One executable test per requirement |

## 6.2 Results (bundled synthetic data)

| Dataset | Notes | Identifiers present | Leaks | Recall | Verification |
|---|---|---|---|---|---|
| Sample corpus | 5 | 26 | 0 | **100 %** | 5/5 PASS |
| Edge cases | 3 | 10 | 1 | 90 % | 2/3 PASS (1 correctly flagged) |
| Both combined | 8 | 36 | 1 | **97.2 %** | 7/8 PASS |

Per-identifier recall on the combined set: Name 100 %, MRN 100 %, DOB 100 %, Phone 100 %, E-mail 100 %, Facility 85.7 % (the single leak).

Other measurements:

- **Requirements:** 7/7 verified by the live self-check.
- **Date formats:** 8/8 caught and normalised to `YYYY-MM-DD`.
- **Tests:** 18/18 pass.
- **Speed:** about 7–11 ms per note on a laptop-class CPU (1,000 notes ≈ under 15 seconds of processing).
- **Text retained:** about 55 % of words (the rest is PHI, or removed copy-forward text).

## 6.3 Ablation — what each stage contributes

| Configuration | Recall | Notes passing | Extra effect |
|---|---|---|---|
| **Full pipeline** | 97.2 % | 7/8 | — |
| Without regex | 63.9 % | 0/8 | 13 leaks |
| Without NER + dictionary | 66.7 % | 0/8 | 12 leaks, 6 dates left |
| Without date normalisation | 97.2 % | 7/8 | **3 date strings left unredacted** |
| Without copy-forward / whitespace / OCR | 97.2 % | 7/8 | No change on this small corpus |

**Interpretation.**

- Regex and NER are each **essential** and complement one another: removing either collapses recall. This proves the use case's claim that regex must work *alongside* NER.
- Date normalisation shows its value through **residual dates**, not identifier recall.
- The remaining stages don't change recall here because spaCy is robust on these short synthetic notes and because the ablation compares identifier survival only. They matter more on real, longer, noisier notes. This is an honest limitation of a tiny corpus, and we say so rather than overclaiming.

## 6.4 The edge-case result is a feature

Note 102 mentions "the comm health annex" (no full stop), which isn't an exact dictionary match. The verifier **FAILs** it, writes it to the edge-case log, and the Review Queue shows it as *High priority*. The reviewer adds the variant to the dictionary; re-running then catches it. This is the **exact loop** the expected-outcome section describes.

## 6.5 Honest caveats

- The corpus is **tiny and synthetic**. The numbers demonstrate the *mechanism*; they are not a production-accuracy claim.
- Verification can only check identifiers **it is given**.
- Production acceptance requires the same evaluation on a **labelled sample of real notes**, ideally with two human annotators.

---

# 7. Conclusion

The project delivers what the use case asks for:

- An automated **first-draft de-identification** of clinical notes in ten file formats.
- All **seven cleaning requirements** implemented, each with a live executable proof.
- A **mandatory verification** step that checks against real identifiers and catches what NER and regex miss.
- An **audit trail** and **edge-case log** for compliance and continuous improvement.
- A **human-in-the-loop** workflow, so compliance staff spot-check rather than redact from scratch.
- An **evaluation layer** (recall, ablation, date coverage) that measures rather than asserts quality.

The central lesson: **neither regex nor NER is sufficient alone; the value comes from combining them, cleaning the text first, and verifying at the end.** Automation is the accelerator; the human reviewer stays accountable.

**Business impact.** If a manual review takes about 3 minutes per note, 30,000 notes is roughly **1,500 hours**. A spot-check review takes a fraction of that, so months of effort shrink to weeks while the human keeps final control.

---

# 8. Limitations and Future Scope

## 8.1 Known limitations

| Limitation | Example | Current mitigation |
|---|---|---|
| Nicknames | "Johnny" for "Jonathan" | Verifier name-part check; logged edge case |
| Unusual date phrasing | "the ninth of February" | Logged; the day is redacted only partially |
| Abbreviated facility names | "RE Wing" | Dictionary expansion |
| Misspelled names | "Natrajan" | NER often catches; verifier checks only the true spelling |
| Small English model | `en_core_web_sm` | Adequate for a first draft |
| Ages over 89, ZIP codes, URLs, device IDs | Other Safe Harbor identifiers | Not yet covered |
| Pickle files | Can be unsafe if untrusted | Only load files you generate |

## 8.2 Future scope

1. **Custom-trained NER model** on annotated hospital notes, fed by the logged edge cases.
2. **Transformer models** (e.g. clinical BERT / de-identification models) for higher recall, kept fully on-premises.
3. **Full Safe Harbor coverage**: ages > 89, ZIP codes, URLs, IP addresses, device and licence numbers, vehicle identifiers.
4. **Surrogate replacement** (consistent fake names, shifted dates) instead of placeholders, preserving temporal relationships for research.
5. **Fuzzy matching** in the dictionary and verifier (edit distance) for misspellings and variants.
6. **Stronger OCR**: layout-aware OCR and image pre-processing (deskew, denoise) for poor scans.
7. **Active learning**: reviewer corrections automatically become training data.
8. **Scale**: batch queues, multiprocessing, a database instead of CSV logs, a REST API (FastAPI).
9. **Security**: role-based access, encrypted storage, tamper-evident audit logs, SSO.
10. **Formal evaluation** with two annotators, precision/recall/F1 per entity type and inter-annotator agreement.
11. **Multilingual support** for non-English notes.
12. **Deployment**: Docker, CI/CD, monitoring of drift in miss rates.

---

# 9. Questions and Answers

## A. Use case and concept

**Q1. What problem does this project solve?**
Hospitals must remove all patient-identifying information (PHI) from clinical notes before sharing them for research. Doing it by hand is too slow for tens of thousands of notes. The project automates a first-draft redaction so humans only spot-check.

**Q2. What is PHI, and what is HIPAA Safe Harbor?**
PHI is Protected Health Information that can identify a patient. Safe Harbor is a HIPAA method under which data counts as de-identified once 18 categories of identifiers (names, dates, locations, phone numbers, MRNs, e-mails and so on) are removed.

**Q3. Why not remove the human reviewer?**
If identifying information slips through, the consequences are serious (legal, ethical, reputational). Automation is a first draft; the human remains accountable.

**Q4. Why NER and not a classifier like Naive Bayes or Bag of Words?**
A classifier only labels a whole document ("contains PHI" or not). We need to find **where** a name or date is so it can be replaced. That is span extraction, which is NER's job.

**Q5. Then why is NER alone not enough?**
MRNs, phone numbers and e-mail addresses aren't named entities, and NER was never trained on them. Regex handles those exact-format patterns. Also, hospital-specific facility names need a custom dictionary.

**Q6. What are the entity types you redact, and their placeholders?**
`[PERSON]`, `[DATE]`, `[ORG]`, `[LOCATION]` (from NER); `[MRN]`, `[PHONE]`, `[EMAIL]`, `[DOB]`, `[SSN]` (from regex).

**Q7. Why is de-identification also called an "information extraction" task?**
Because we extract specific pieces of information (spans) from unstructured text, rather than predicting a category for the text.

## B. Data and cleaning

**Q8. Why is the data considered "messy"?**
Mixed sources (typed and scanned), OCR errors, several date formats, EHR copy-forward, line-wrap artifacts, and hospital-specific names.

**Q9. Why normalise dates before NER?**
So all variants become one canonical form and every variant can be confirmed as caught. spaCy misses two-digit years and dash-separated dates more often.

**Q10. What is copy-forward, and why remove it?**
A nurse's new note begins by quoting the prior visit in full. It repeats the patient's PHI at another nesting level. If only the first mention is redacted, a second copy of the identifier survives.

**Q11. Why apply OCR correction only to scanned notes?**
Scanned notes have a known error pattern. Applying the same corrections to typed notes would create errors where none existed (for example changing valid text).

**Q12. How do you avoid `OO → 00` corrupting normal words like "Good"?**
The rule is applied only inside tokens that already contain a digit, such as `OO4521`.

**Q13. Why clean whitespace before NER?**
A name split by a line break (`John\nMiller`) is often not recognised as a single PERSON entity.

**Q14. Why is the facility dictionary needed?**
Names like "Riverside East Wing" or "the Comm. Health annex" are internal and spaCy was never trained on them.

**Q15. Why are "yesterday" and "3 days ago" kept?**
They are relative expressions, not identifying dates. Removing them lowers research value without improving privacy.

## C. Code and design

**Q16. Why does the pipeline replace entities from the end of the string backwards?**
Replacing changes string length. Working backwards keeps the earlier character offsets valid.

**Q17. What happens when two detectors flag overlapping text?**
Overlaps are resolved by priority (dictionary, then regex, then spaCy) and then by longest span, so only one replacement is applied.

**Q18. What was the `[[ORG]]` bug?**
After the regex stage inserted `[DOB]`, spaCy tagged the word "DOB" inside the brackets as an organisation and wrapped it again. We now skip entities that overlap an existing placeholder.

**Q19. Why is the verifier separate from NER?**
NER decides what to redact. Verification independently checks the output against the **actual** identifiers from the record, so it catches what NER misses instead of trusting NER's own judgment.

**Q20. What does the verifier check?**
Full name, each name part, MRN, DOB in many written formats, phone digits, e-mail and facility.

**Q21. What if the user gives no verification details?**
The dashboard warns that verification had nothing to check, instead of displaying a misleading "100 %".

**Q22. Why pickle files?**
To keep resources (dictionary, OCR rules) separate from code so they can be updated without changing logic. (Caveat: only load pickles you created, since untrusted pickles are unsafe.)

**Q23. Why is the pipeline a service class?**
It gives one entry point (`process_text`, `process_dataset`) used by the dashboard, the command line and the tests, and it records a trace per stage.

**Q24. Why cache the pipeline in Streamlit?**
Loading spaCy is slow. `st.cache_resource` loads it once and reuses it across interactions.

**Q25. Why session state and a signature?**
Streamlit re-runs the script on every interaction. Without a signature, each click would reprocess and re-log the same note.

**Q26. Why read CSVs as strings?**
Otherwise `004521` becomes the number `4521` and the verifier could not find the true MRN.

**Q27. How does the ablation study work?**
Each pipeline stage can be disabled by name. We re-run the corpus with one stage off and compare recall, pass rate and residual dates against the full pipeline.

## D. Evaluation

**Q28. How do you measure accuracy without labelled entity spans?**
We use the structured EHR fields as ground truth: for each identifier present in the original, we test whether it still appears in the output. This measures **leakage** directly, which is what matters for compliance.

**Q29. What are your results?**
100 % recall on the 5-note sample; 97.2 % on all 8 notes; 7/8 passing (the failure is a deliberately hard note); all 7 requirements verified; 18 tests pass.

**Q30. Why is 100 % recall not a claim of production accuracy?**
The corpus is small and synthetic. It demonstrates the mechanism. A real evaluation needs a labelled sample of real notes.

**Q31. Why do some ablations show no change?**
On short, clean synthetic notes, other detectors compensate, and identifier recall isn't sensitive to those stages. They matter more on real, noisy notes. We report this honestly.

**Q32. Do you measure precision?**
Not with span-level ground truth. We use "text retained" as a proxy for over-redaction. A formal precision/recall/F1 evaluation with annotated spans is future work.

**Q33. Why is a FAIL in the edge-case set good news?**
It proves the safety net works: a leak is caught, logged and routed to a human instead of passing silently.

## E. Limitations, ethics and future

**Q34. What are the main limitations?**
Nicknames, unusual date phrasing, abbreviated facility names, misspellings, and some Safe Harbor identifiers (ages over 89, ZIP codes, URLs) not yet covered.

**Q35. Is patient data sent to any external service?**
No. spaCy, Tesseract and all logic run locally. That is deliberate.

**Q36. Can it replace the compliance team?**
No. It is designed to **assist** them.

**Q37. How would you improve it?**
Train a custom NER on annotated hospital notes, use clinical transformer models, add remaining Safe Harbor identifiers, use surrogate replacement, add fuzzy matching, and scale with an API and database.

**Q38. How does the system learn from mistakes?**
Failures are written to `edge_cases.csv`; the reviewer can add variants to the dictionary; over time the log becomes training data for a custom model.

**Q39. What is the difference between de-identification and anonymisation?**
De-identification removes direct identifiers under a defined standard (Safe Harbor) but can, in theory, leave re-identification risk. Anonymisation aims for irreversibility. HIPAA Safe Harbor is a de-identification standard.

**Q40. What would you do first with real data?**
Sample and annotate a set of real notes, run the evaluation, look at every leak, extend the dictionary and rules, and only then scale up, always keeping the human review step.

---

# 10. Speaking Script

## 10.1 One-minute version (elevator pitch)

> "Hospitals often need to share clinical notes with researchers, but by law every patient identifier must be removed first. Doing that by hand takes months for tens of thousands of notes. I built an automated PHI de-identification system. It uses regex for structured data like MRNs and phone numbers, spaCy named entity recognition for names, dates, places and organisations, and a verification scan that checks the result against the patient's real identifiers. It produces a first-draft redaction, so the compliance team spot-checks instead of redacting from scratch. It comes with a Streamlit dashboard, an audit log and a live evaluation. On my test data it removed 100 percent of identifiers in the sample set and correctly flagged the one hard case for human review."

## 10.2 Full presentation script (about 7–8 minutes)

**[Slide/section 1 — Opening, 30 s]**

"Good [morning/afternoon]. Today I'll present my **Healthcare PHI De-Identification System**. It answers a real problem: how can a hospital safely share clinical notes for research?"

**[Section 2 — The problem, 60 s]**

"Riverside Regional wants to share years of Emergency Department notes with a university partner. The agreement says every note must meet the HIPAA Safe Harbor standard, so no names, dates, locations, phone numbers, medical record numbers or organisation names can leave the hospital.

Today a small compliance team does this by hand, a few minutes per note. The study needs tens of thousands of notes, which means months of reading. And the notes are messy: some are typed, some are scanned old records with OCR errors, dates come in many formats, and the EHR copies previous notes into new ones, so a patient's name can appear several times."

**[Section 3 — Approach, 75 s]**

"The hospital's plan is not to remove the human. My system produces a **first-draft redaction**, and the reviewer spot-checks it.

I used **Named Entity Recognition**, because this is not classification. We aren't labelling a note as category A or B. We need to find *where* the name or date is, so we can replace it. But NER alone isn't enough, because an MRN or a phone number isn't a named entity. So the system combines **regex and spaCy**, each doing the job it is best at."

**[Section 4 — Pipeline, 90 s]**

"Here is the pipeline. First, a **regex pre-pass** removes MRNs, phone numbers, e-mails and dates of birth. Second, **date normalisation** converts every date format to one standard form. Third, **copy-forward removal** strips quoted prior notes. Fourth, **whitespace cleaning** fixes broken lines, so a name split across two lines is one name again. Fifth, **OCR correction**, and only for scanned notes, because applying it to typed notes would introduce errors. Sixth, **spaCy NER plus a custom facility dictionary** redacts people, dates, places and organisations, including hospital names spaCy has never seen. Seventh, a **verification scan** searches the output for the patient's real name, MRN, date of birth, phone, e-mail and facility. Finally, everything is written to an **audit log**.

The order is deliberate: structured data goes before NER, and dates, copy-forward and line-breaks are cleaned before NER sees the text."

**[Section 5 — Demo, 90 s]** *(open the dashboard)*

"Let me show it. This is the Streamlit dashboard. I'll load the demo note. On the left is the original with detected identifiers underlined; on the right is the redacted note with colour-coded placeholders. The cards show entities redacted, verification result, and time, about twenty milliseconds.

Below, the trace shows how the text changes at each stage. The verification table shows each check passed.

In the Batch tab I can process a whole dataset. The Evaluation tab shows recall by identifier type, a heatmap of which identifiers were removed or leaked, and an ablation study. And here in the Review Queue, the failed note appears at the top with high priority. I can add the missing hospital name to the dictionary, re-run, and the note is now caught."

**[Section 6 — Results, 60 s]**

"For evaluation, I use the patient's structured record as ground truth and test whether each identifier survives. On the sample set, 100 percent of identifiers were removed and all five notes passed verification. Adding a harder edge-case set gives 97.2 percent recall, and the one failure was correctly caught by the verifier and sent to review. The ablation shows both regex and NER are essential: removing either drops recall from about 97 percent to about 64 to 67 percent. All seven cleaning requirements are verified by live tests, and all 18 automated tests pass."

**[Section 7 — Limitations & future, 45 s]**

"This was tested on a small synthetic dataset, so the numbers show the mechanism, not production accuracy. Known gaps are nicknames, unusual date wording and abbreviated facility names. Next steps: train a custom NER on annotated hospital notes, use clinical transformer models, cover the remaining Safe Harbor identifiers, and replace with consistent surrogate values instead of placeholders."

**[Section 8 — Conclusion, 30 s]**

"To conclude: combining regex, NER, careful cleaning and a mandatory verification step gives a fast, auditable first draft, while the human reviewer stays in control. That turns months of manual redaction into a much faster spot-check. Thank you. I'm happy to take questions."

## 10.3 Tips for delivering it

- **Slow down** on the pipeline order — it's the part examiners ask about.
- **Be upfront** that the data is synthetic and the sample is small. It builds trust.
- **If asked something you don't know**, say: "That's a limitation I've noted under future scope."
- **Have the dashboard already open** on the demo note, and the Review Queue ready.
- **Three sentences to remember:**
  1. "Regex handles structured PHI, NER handles free-text entities."
  2. "Verification checks against the real identifiers, not what NER flagged."
  3. "Automation drafts; the human decides."

---

*End of document.*
