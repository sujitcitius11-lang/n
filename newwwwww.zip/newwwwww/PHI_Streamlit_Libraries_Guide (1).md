# PHI De-Identification Studio — Streamlit, Libraries & Alternatives

**Contents**

1. How Streamlit works (the 6 ideas you must know)
2. `streamlitmain.py` walkthrough, top to bottom
3. Every tab in detail (widgets → state → backend call → output)
4. Session-state variables (the app's "memory")
5. Data flow: one click, end to end
6. Known quirks and gotchas
7. Every library used (what, where, why)
8. Alternatives for every library
9. Alternatives to Streamlit itself
10. Suggested upgrade path

---

# 1. How Streamlit works — the 6 ideas you must know

## 1.1 The script re-runs from top to bottom on every interaction
Streamlit has no "callbacks and a page that stays". Every click, keystroke-commit, dropdown change or file upload **re-executes the whole `streamlitmain.py` from line 1**. Widgets return their *current value* during that run.

Consequence for this project: anything expensive (loading spaCy, processing a note) must be **cached** or **guarded**, otherwise it would happen on every click.

## 1.2 `st.session_state` = memory between re-runs
A dictionary that survives re-runs within one browser session. Normal Python variables are reset each run. This app stores the latest result, the batch, the ablation table and the reviewer decisions in it.

## 1.3 Caching
| Decorator | What it caches | Used here for |
|---|---|---|
| `@st.cache_resource` | A **shared object** created once (models, connections). Not copied. | `load_pipeline()` — loads spaCy + dictionary + OCR rules **once** |
| `@st.cache_data` | A **returned data value** (copied per call). Keyed by arguments. | `bundled(name)` — reads the sample/edge CSV once |

> Gotcha: because `bundled()` is cached, editing `data/*.csv` while the app runs won't show until you clear the cache (menu → "Clear cache") or restart.

## 1.3b Widgets
A widget (`st.button`, `st.text_input` …) is drawn and returns its value. `st.button` returns `True` **only on the run right after the click**, which is why the app uses signatures and session state (see 1.4).

## 1.4 Guarding against repeated work — the "signature" pattern
Because the script re-runs constantly, the Redact tab builds a tuple `sig = (source_name, hash(text), scanned, metadata, write_audit)` and only runs the pipeline when `sig` differs from the previous one (`st.session_state.single_sig`). Otherwise the same note would be processed and written to the audit log again on every re-run.

## 1.5 Layout primitives
`st.set_page_config`, `st.sidebar`, `st.tabs`, `st.columns`, `st.expander`, `st.status`. Layout is built by nesting `with` blocks.

## 1.6 Styling
Streamlit's built-in look is customised in two ways:
1. `.streamlit/config.toml` — theme colours, font, upload limit (`maxUploadSize = 50` MB).
2. A big CSS string injected with `st.markdown(CSS, unsafe_allow_html=True)` — hero banner, KPI cards, tabs, sidebar gradient.

---

# 2. `streamlitmain.py` walkthrough, top to bottom

## 2.1 Imports (lines 1–17)
| Import | Why |
|---|---|
| `io`, `json`, `os`, `pickle`, `tempfile`, `time` | bytes buffer for Excel, JSON download, file extension, saving the facility dictionary, temp files for uploads |
| `pandas as pd` | all tables |
| `streamlit as st` | the UI |
| `config` constants | paths, colours, supported formats, 99 % target |
| `FileReader` | turns uploads into text |
| `DateNormalizer` | used by the EDA tab |
| `PHIDeidentificationPipeline, STAGES, load_dataset` | the backend |
| `services.evaluation_service as ev` | metrics |
| `utils.visuals as vz` | Plotly figures + HTML helpers |

## 2.2 `st.set_page_config(...)` (lines 23–28)
Must be the **first Streamlit call**. Sets the browser-tab title (`PHI De-Identification Studio`), icon 🏥, `layout="wide"` (uses the full screen width), `initial_sidebar_state="expanded"`.

## 2.3 The CSS block (lines 30–70)
Not logic, only looks. Main classes:

| CSS class | Where it appears |
|---|---|
| `.hero`, `.pill` | Purple gradient banner at the top with the pill tags |
| `.kpi-row`, `.kpi`, `.kpi-icon/-label/-value/-sub` | The coloured metric cards (`vz.kpi_row`) |
| `.note-box` | White box that shows original / redacted text |
| `.ph` | Coloured `[PERSON]`, `[DATE]` chips |
| `.hl` | Underline highlight of detected PHI in the original |
| `.flow`, `.step`, `.arrow` | The horizontal pipeline diagram |
| `.section-title` | Section headings |
| `.stTabs …`, `[data-testid="stSidebar"]` | Restyles Streamlit's own tabs and sidebar |

`unsafe_allow_html=True` is needed because Streamlit strips raw HTML by default. It is safe here because the only dynamic text is passed through `html.escape()` inside `visuals.py`.

## 2.3b Loading the backend (lines 77–88)
```python
@st.cache_resource(show_spinner="Loading spaCy model & resources...")
def load_pipeline():
    return PHIDeidentificationPipeline()

pipeline = load_pipeline()
reader   = FileReader()
logger   = pipeline.audit_logger
```
spaCy loading takes seconds; caching means it happens once per server process, not per click.

## 2.4 Small helper functions (lines 90–130)
| Helper | Purpose |
|---|---|
| `show(fig)` | Calls `st.plotly_chart(fig, width="stretch")`; falls back to the older `use_container_width=True` if the installed Streamlit is older. Keeps the app working across Streamlit versions. |
| `table(df)` | Same idea for `st.dataframe` |
| `html(x)` | Shortcut for `st.markdown(x, unsafe_allow_html=True)` |
| `section(title)` | Renders a styled section heading |
| `to_excel(sheets)` | Writes several DataFrames into an in-memory `.xlsx` (openpyxl) and returns the bytes for `download_button`; returns `None` on failure |
| `bundled(name)` | Cached loader for `data/sample_notes.csv` or `data/edge_case_notes.csv` (read **as text** so MRN `004521` keeps its zeros) |

## 2.5 Session state initialisation (lines 136–139)
```python
for k, v in {"single": None, "single_sig": None, "batch": None, "ablation": None,
             "selfcheck": None, "decisions": {}, "uploaded_batch": None}.items():
    st.session_state.setdefault(k, v)
```
`setdefault` creates each key only the first time, so re-runs don't wipe them. See section 4.

## 2.6 `run_batch(df, name, log)` (lines 142–149)
1. Creates `st.progress(0)`.
2. Calls `pipeline.process_dataset(df, save=True, ..., progress=callback)`; the callback updates the bar to `i/n`.
3. Removes the bar and stores `{"out", "traces", "name", "df"}` in `session_state.batch`.
4. Sets `ablation = None` so an old ablation table isn't shown for new data.

This one function is used by the Batch tab, the Evaluation tab's two buttons.

## 2.7 Sidebar (lines 156–187)
Everything inside `with st.sidebar:`.

| Widget | Variable | Meaning |
|---|---|---|
| `st.text_input("Patient Name")` | `patient_name` | Ground-truth name the verifier searches for |
| `st.text_input("MRN")` | `mrn` | Ground-truth MRN |
| `st.text_input("DOB")` | `dob` | Ground-truth date of birth |
| `st.expander("More identifiers")` → Phone, Email, Facility | `phone_meta`, `email_meta`, `facility_meta` | Optional extra checks |
| `st.radio("OCR correction")` Auto-detect / Scanned note / Natively typed | `scan_mode` | Decides whether OCR fixes run |
| `st.toggle("Write to audit log")` | `write_audit` | Whether runs are logged |
| `st.write(formats)` | – | Shows supported extensions |
| `html(vz.legend_html())` | – | Colour legend chips |

Afterwards all six identifier fields are combined into one dict:
```python
metadata = {"patient_name":..., "mrn":..., "dob":..., "phone":..., "email":..., "facility":...}
```
This `metadata` dict is what makes the verification step meaningful. **If it's empty, `verified` is False and the UI warns instead of showing a fake 100 %.**

> The sidebar metadata only affects the **Redact tab**. Batch mode reads identifiers from each row's columns instead.

## 2.8 Hero banner (lines 190–200)
A static HTML block with the title and six "pills" (Regex + spaCy NER, OCR-aware, …).

## 2.9 Creating the tabs (lines 202–204)
```python
tab_redact, tab_batch, tab_eval, tab_review, tab_eda, tab_audit, tab_arch = st.tabs([...])
```
> **Important Streamlit fact:** *all seven tab bodies execute on every re-run*, even the ones not visible. That's why the Evaluation tab checks `if not st.session_state.batch:` first — so it doesn't crash before any data exists.

---

# 3. Every tab in detail

## 3.1 🛡️ Redact (lines 209–334) — one note at a time

**Input area**
| Widget | Behaviour |
|---|---|
| `st.file_uploader(type=SUPPORTED_FORMATS)` | Accepts TXT, CSV, JSON, PDF, DOCX, PNG, JPG, JPEG, TIFF, BMP |
| `st.text_area("...or paste a note")` | Free text |
| Button **Redact pasted text** | Sets `run_paste=True` for one run |
| Button **Try a demo note** | Loads row 3 of the sample dataset **and its own metadata** so verification is meaningful |

**Getting the text**
1. *Upload:* bytes are written to a temp file (`tempfile.NamedTemporaryFile`) and `FileReader.read_file()` extracts text (OCR for images). If it's a CSV that has a `note_text` column, the app also stores it in `session_state.uploaded_batch` and shows an info box pointing you to the Batch tab.
2. *Paste:* uses the pasted string.
3. *Demo:* pulls the row and overwrites `metadata`.

**Deciding "scanned"**
```python
scanned = {"Auto-detect": is_image, "Scanned note": True, "Natively typed": False}[scan_mode]
```
Auto-detect treats **images** as scanned (they went through Tesseract) and everything else as native.

**Running the pipeline (guarded by the signature)** → `pipeline.process_text(...)` inside `st.status(...)`, which shows a spinner then "Pipeline complete". Result goes into `session_state.single`, called `t` (the *trace*).

**Displayed results (in order)**
1. **KPI cards** (`vz.kpi_row`): Entities redacted · Verification (PASS/FAIL, checks run) · Compliance rate · Words · Text retained % · Latency ms.
   *Compliance rate* = 100 % if PASS, otherwise `passed checks / total checks`.
2. **Banner:** `st.warning` (no identifiers supplied), `st.success` (PASS) or `st.error` (FAIL — manual review).
3. **Original vs Redacted:** two columns; left shows the original with detected spans underlined (`highlight_original`), right shows the redacted text with coloured chips (`highlight_redacted`); each also has a copyable `st.text_area`.
4. **Analytics (3 charts):** donut of entities by type · stage-impact bars (how many characters each stage changed) · per-stage latency.
5. **Verification Result:** a table of every check (`Patient name (full)`, `(part)`, `MRN`, `Date of birth`, `Phone`, `Email`, `Facility`) coloured green/red with a pandas Styler; plus a list of issues.
6. **Pipeline Trace:** a flow diagram (✔ marks stages that changed the text) and an **expander per stage** containing that stage's JSON info and the text *after* the stage. This is the best place to *see* why something was or wasn't redacted.
7. **Detected Entities:** table `label / text / source` (source = `regex`, `spacy` or `dictionary`).
8. **Compliance Summary:** the pipeline sentence and ✅/❌ line.
9. **Downloads:** redacted `.txt`, JSON compliance report, entities `.csv`.

## 3.2 📦 Batch (lines 340–424) — a whole dataset

| Widget | Purpose |
|---|---|
| `st.selectbox("Dataset")` | Sample (5) / Edge cases (3) / Both / Uploaded CSV |
| `🚀 Run batch` button | Calls `run_batch(...)` |
| `st.toggle("Write batch results to audit log")` | Log or not |

After a run:
- **KPI cards:** notes processed, entities, pass rate, need review, scanned notes, average latency.
- **4 charts:** PASS/FAIL pie · entities stacked per note · density scatter (text length vs entities) · sunburst of which detector (regex / spaCy / dictionary) found what.
- **Results table** with `st.multiselect` status filter.
- **Inspect a note** (`st.selectbox`) → original vs redacted side by side.
- **Downloads:** CSV, JSON, and a 3-sheet Excel (`redacted_notes`, `entities`, `summary`).

Required column: `note_text`. Optional: `patient_name, mrn, dob, phone, email, facility, is_scanned` — these enable per-note verification and evaluation.

## 3.3 📊 Evaluation (lines 430–505)

If no batch exists it shows a **Run evaluation on the bundled corpora** button. Otherwise:

| Element | Meaning |
|---|---|
| Button **➕ Re-run on sample + edge cases** | Re-runs the 8-note set (5 + 3) |
| 3 **gauges** | Identifier recall (target 99 %) · Verification pass rate · Text retained (utility) |
| Warning / success message | Number of leaked identifiers |
| **Recall bar** | Recall per identifier type vs the 99 % line |
| **Radar** | Same recall as a shape (dents = weak types) |
| **Leak heatmap** | Note × identifier grid: removed / LEAKED / n/a |
| **Group bars** | Scanned vs native recall |
| **Stage latency** | Average ms per pipeline stage |
| **Ablation** (button) | Switches each stage off and re-scores — shows what each stage contributes |
| **Date-format coverage** | 8 date styles → each must end as `[DATE]` |
| **Download** | Recall report CSV |

Key definitions (in `evaluation_service.py`):
- *Identifier present* = appears in the original note text (after ignoring spaces/punctuation).
- *Removed* = no longer present in the redacted text; *LEAKED* = still present.
- *Recall* = removed ÷ present. *n/a* = never appeared, so not counted.

## 3.4 👩‍⚕️ Review Queue (lines 511–564) — the human-in-the-loop

1. Builds a table from the batch output: `note_id, verification_status, entities_found, issues`.
2. Adds **priority**: FAIL → 🔴 High, PASS → 🟢 Spot-check.
3. Adds **decision** from `session_state.decisions` (default **Pending**).
4. Shows it in `st.data_editor`; only the *decision* column is editable (a `SelectboxColumn` with Pending / Approved / Needs fix / Rejected). Everything else is in `disabled=[...]`.
5. Saves edits back: `session_state.decisions = dict(zip(note_id, decision))`.
6. Four KPI cards count each decision. (**"8 pending" simply means 8 notes with no decision yet.**)
7. **Export approved notes** button — only notes marked Approved (`note_id, redacted_text`), disabled when none.
8. **Teach the system:** text box + **Add to dictionary** → loads `facility_dictionary.pkl`, appends the string, saves it, and also updates the live in-memory list (`pipeline.ner_redactor.facilities`) so the next batch uses it without restart.
9. **Logged edge cases:** last 20 rows of `logs/edge_cases.csv` (every FAIL ever recorded).

## 3.5 🔎 EDA Explorer (lines 570–611)

| Element | Purpose |
|---|---|
| Radio: Sample / Edge cases / Batch in memory | Which dataset to inspect |
| KPI cards | records, columns, missing values, duplicates, average words |
| 3 charts | scanned vs native · text-length histogram · facility distribution |
| **Dirty-data census** | Counts (by regex) date formats, OCR/line-break/copy-forward artefacts, and structured PHI — the evidence that justifies each pipeline stage |
| Preview + download | First 20 rows, and the EDA CSV |

## 3.6 📋 Audit Log (lines 617–649)
Reads `logs/audit_log.csv` through `AuditLogger.read_log()`.
- KPI cards: entries, PASS, FAIL, entities logged, distinct files.
- Timeline chart, PASS/FAIL pie, status filter, last 200 rows newest-first.
- **Download audit log.**
- **Danger zone:** a checkbox *and* a button are both required to clear the log (`st.rerun()` afterwards).

## 3.7 🏗️ Architecture & Compliance (lines 655–682)
- Pipeline flow diagram (the 11 boxes).
- Short "why NER, not classification" explanation.
- **Run self-check** — `ev.run_self_check(pipeline)` runs one executable test per each of the 7 cleaning requirements; progress bar shows `n/7`. It also runs automatically the first time (`or st.session_state.selfcheck is None`).
- "Expected outcomes" table mapping each business outcome to where the app delivers it.

---

# 4. Session-state variables (the app's memory)

| Key | Holds | Set by | Used by |
|---|---|---|---|
| `single` | Full trace of the last single note | Redact tab | Redact tab display |
| `single_sig` | Signature of the last processed input | Redact tab | Prevents re-processing |
| `batch` | `{out, traces, name, df}` | `run_batch()` | Batch, Evaluation, Review, EDA |
| `ablation` | Ablation results DataFrame | Evaluation button | Evaluation display |
| `selfcheck` | Self-check DataFrame | Architecture tab | Architecture tab |
| `decisions` | `{note_id: decision}` | Review Queue editor | Review KPIs + export |
| `uploaded_batch` | `(filename, DataFrame)` | Redact tab (CSV with `note_text`) | Batch dropdown |

---

# 5. Data flow — one click, end to end

```
User clicks "Re-run on sample + edge cases"
  → Streamlit re-runs streamlitmain.py from the top
  → load_pipeline() returns the cached pipeline (no reload)
  → button returns True → run_batch(concat(sample, edge), "sample+edge", write_audit)
       → pipeline.process_dataset(df)
            for each row:
              process_record(row) → process_text(text, is_scanned, metadata)
                 regex → dates → copy-forward → whitespace → OCR (if scanned)
                 → NER + facility dictionary → Verifier → AuditLogger
       → saves data/output/redacted_notes.csv
  → results stored in st.session_state.batch
  → st.rerun()  (fresh run so every tab sees the new batch)
  → Evaluation tab: identifier_matrix → recall_by_type → gauges/charts
  → Review tab: FAIL rows sorted to the top as 🔴 High
```

---

# 6. Known quirks and gotchas

| Quirk | Effect | Fix / note |
|---|---|---|
| All tabs run every re-run | Slower as the app grows | Guard with `if` checks, or use `@st.fragment` |
| `@st.cache_data` on `bundled()` | CSV edits invisible until cache clear | Menu → Clear cache, or restart |
| Reviewer decisions are keyed by `note_id` and live in `session_state` | Lost on browser refresh; decision "Needs fix" stays after you fix the note and re-run | Re-set it to Approved; persist to a CSV for a real workflow |
| Uploaded files saved with `delete=False` in temp | Temp files accumulate | Delete with `os.remove` after reading |
| `hash(text)` in the signature | Fine within a session (Python randomises hashes per process, not per run) | Use `hashlib.sha256` if you ever persist signatures |
| Audit log is a CSV | No locking, unsafe with several users | Move to SQLite/Postgres |
| Sidebar metadata only affects the Redact tab | Batch uses row columns | Documented in the UI text |
| Pickle for the dictionary | Unsafe to load from untrusted sources | Use JSON (see alternatives) |
| Facility matching (fixed) | Earlier, `Comm. Health annex` did not match `comm health annex` | `_facility_pattern()` now ignores case and punctuation |

---

# 7. Every library used

## 7.1 Third-party libraries (from `requirements.txt`)

| Library | Version | Used in | What it does here | Why chosen |
|---|---|---|---|---|
| **streamlit** | ≥ 1.35 | `streamlitmain.py` | The whole web UI | Python-only, no HTML/JS needed, widgets built in |
| **spacy** + `en_core_web_sm` | ≥ 3.7 | `ner_redactor.py` | Finds PERSON, DATE, ORG, GPE | Fast, CPU-only, **offline** (PHI never leaves the machine) |
| **pandas** | ≥ 2.0 | everywhere | Datasets, results, audit log, Excel writer | Standard tabular tool |
| **numpy** | (pandas dependency) | `visuals.py` | Numeric helpers for charts | Comes with pandas |
| **plotly** | ≥ 5.20 | `visuals.py` | Donut, gauge, radar, heatmap, sunburst, ablation charts (`graph_objects` + `express`) | Interactive hover/zoom, good for non-programmers |
| **python-dateutil** | ≥ 2.8 | `date_normalizer.py`, `verifier.py` | `parser.parse()` turns many date styles into one; generates DOB variants | Handles `3-3-26` and `March 3, 2026` without custom parsers |
| **PyPDF2** | ≥ 3.0 | `file_reader.py` | Extracts text from PDFs | Lightweight, pure Python |
| **python-docx** | ≥ 1.0 | `file_reader.py` | Reads Word paragraphs **and tables** | PHI can sit in tables |
| **pytesseract** | ≥ 0.3.10 | `file_reader.py` | Python wrapper that calls Tesseract OCR | Free, local |
| **Tesseract** (binary, not pip) | – | via pytesseract | The actual OCR engine | Must be installed separately |
| **Pillow** | ≥ 10.0 | `file_reader.py` | Opens images, converts to grayscale for OCR | Standard imaging library |
| **openpyxl** | ≥ 3.1 | `streamlitmain.py` (via pandas) | Writes `.xlsx` exports | Compliance teams use Excel |
| **matplotlib** | ≥ 3.8 | `eda.py` | Static PNG charts for reports | Simple, file output |
| **pytest** | ≥ 8.0 | `tests/` | Automated tests | Guards against regressions |

## 7.2 Python standard library
| Module | Used for |
|---|---|
| `re` | All regex: MRN, phone, email, SSN, copy-forward, whitespace, facility matching |
| `pickle` | Load/save `facility_dictionary.pkl`, `ocr_rules.pkl` |
| `csv` | Writing the audit log rows |
| `json` | Reading JSON inputs, exporting reports |
| `os`, `pathlib`, `shutil`, `tempfile` | Paths, finding the Tesseract binary, temp files |
| `io` | In-memory Excel buffer |
| `time` | Per-stage latency timing |
| `datetime` | Audit timestamps |
| `html` | `html.escape()` so note text can't inject HTML into the page |
| `sys` | Path setup in scripts/tests |

## 7.3 Techniques (not libraries)
Regex pre-pass, rule-based cleaning, dictionary lookup, span-overlap resolution (greedy, priority dictionary > regex > spaCy), ablation study, recall metrics.

---

# 8. Alternatives for every library

## 8.1 NER / PHI detection (spaCy)
| Alternative | Notes | Trade-off |
|---|---|---|
| **Microsoft Presidio** | Purpose-built PII/PHI framework: built-in recognisers (phone, email, SSN, credit card…), custom recognisers, anonymiser. Can use spaCy underneath. | Very close to what this project hand-builds; a strong "production" choice |
| **Hugging Face clinical de-id models** (e.g. Stanford AIMI de-identifier, `obi/deid_roberta_i2b2`) | Transformer models **trained on clinical notes** | Much higher recall on clinical text; heavier (GPU helps); still can run offline |
| **John Snow Labs Spark NLP for Healthcare** | Commercial, clinical de-identification pipelines | Licensed; best accuracy; heavy setup |
| **Philter (UCSF)** | Open-source clinical PHI filter, rules + dictionaries | Older, less flexible |
| **scispaCy / medspaCy** | spaCy models/extensions for biomedical text | Good for clinical entities; not de-id by itself |
| **Stanza, Flair, NLTK** | Other NER toolkits | Stanza/Flair more accurate than `sm` but slower; NLTK weakest |
| **`en_core_web_lg` / `en_core_web_trf`** | Bigger spaCy models | Same API; better accuracy, slower |
| **Cloud APIs** (AWS Comprehend Medical, Google Healthcare API, Azure) | Managed de-id | **Sends PHI off-site** — needs a BAA; contradicts the offline design |

## 8.2 Regex
| Alternative | Notes |
|---|---|
| **`regex` module** | Drop-in superset of `re` (fuzzy matching, better Unicode) — would allow *fuzzy* facility matching |
| **`phonenumbers`** | Google's phone parser; more reliable than a hand regex, handles international numbers |
| **Presidio pattern recognisers** | Pre-made, tested patterns with context words |

## 8.3 Date handling (python-dateutil)
| Alternative | Notes |
|---|---|
| **`dateparser`** | Also parses "3 days ago", multiple languages |
| **`datefinder`** | *Finds* dates inside text |
| **`pandas.to_datetime`** | Fine for columns, not free text |
| **`arrow`, `pendulum`** | Nicer date objects, less flexible parsing |
| **HeidelTime / SUTime** | Temporal taggers for clinical text |

## 8.4 Storage of the dictionary / rules (pickle)
| Alternative | Why better |
|---|---|
| **JSON / YAML** | Human-readable, diff-able in Git, **no code-execution risk** |
| **SQLite** | Concurrent access, history of who added what |
| **joblib** | Same risks as pickle, better for big arrays |

## 8.5 Data handling (pandas)
**Polars** (faster, multithreaded), **DuckDB** (SQL on files), plain **csv** module (fine for tiny data). For tens of thousands of notes pandas is enough; for millions consider Polars/Spark.

## 8.6 PDF reading (PyPDF2)
> **PyPDF2 is deprecated** — the project moved back to **`pypdf`**. Prefer that.

| Alternative | Notes |
|---|---|
| **pypdf** | Direct successor, same API style |
| **pdfplumber** | Better layout and tables |
| **PyMuPDF (fitz)** | Fastest, robust, also renders pages to images for OCR |
| **pdfminer.six** | Fine-grained layout control |
| **OCRmyPDF** | Adds a text layer to *scanned* PDFs (PyPDF2 returns nothing for those) |

## 8.7 Word reading (python-docx)
`docx2txt` (simplest text dump), `mammoth` (Word → HTML/Markdown), `docx2python` (headers, footers, footnotes, tables).

## 8.8 OCR (pytesseract / Tesseract)
| Alternative | Notes |
|---|---|
| **EasyOCR** | Deep-learning OCR, often better on messy scans, GPU-friendly |
| **PaddleOCR** | Very accurate, layout-aware |
| **docTR** | Modern detection + recognition pipeline |
| **TrOCR (Hugging Face)** | Transformer OCR, strong on handwriting |
| **Cloud OCR** (Textract, Google Vision, Azure) | Accurate, but sends PHI off-site |
| **OpenCV pre-processing** | Not an OCR engine; deskew/denoise/threshold **before** Tesseract to cut errors like `OO4521` |

## 8.9 Image handling (Pillow)
**OpenCV (`opencv-python`)** for heavy pre-processing; **scikit-image** for filters.

## 8.10 Charts (Plotly, matplotlib)
| Alternative | Best for |
|---|---|
| **Altair (Vega-Lite)** | Clean declarative charts, native in Streamlit |
| **Streamlit native charts** (`st.line_chart`, `st.bar_chart`) | Quick simple charts, zero code |
| **Bokeh** | Interactive, dashboards |
| **seaborn** | Statistical plots on top of matplotlib |
| **Matplotlib only** | Static images for reports (already used in `eda.py`) |
| **Plotly Dash figures** | If you move to Dash |

## 8.11 Excel export (openpyxl)
**XlsxWriter** (write-only, faster, richer formatting), or export **CSV** and let Excel open it.

## 8.12 Testing (pytest)
`unittest` (built-in, more verbose), `hypothesis` (generates random test inputs — great for regex edge cases).

## 8.13 Audit log (CSV via `csv`)
**SQLite** (built-in, transactional), **PostgreSQL**, or a tamper-evident store (hash-chained log, append-only object storage). CSV is fine for a demo, not for multi-user compliance.

---

# 9. Alternatives to Streamlit itself

| Framework | Style | Pros | Cons for this project |
|---|---|---|---|
| **Streamlit** *(current)* | Script re-runs top-to-bottom | Fastest to build, huge community, built-in upload/download/data-editor | Full re-run each click; limited multi-user state; awkward for complex workflows |
| **Gradio** | Function-in / function-out UI | Great for ML demos, easy sharing | Weaker multi-tab dashboards and tables |
| **Dash (Plotly)** | Callback-based | Fine control, enterprise-grade, works well with Plotly | More boilerplate |
| **Panel / HoloViz** | Reactive widgets | Good for data science dashboards, Jupyter friendly | Smaller community |
| **Shiny for Python** | Reactive programming | Only re-computes what changed | Newer, fewer examples |
| **NiceGUI / Reflex / Flet** | Component-based, pure Python | More "real app" feel, real state handling | More code |
| **FastAPI + React/Vue** | Separate backend and frontend | Production-grade, auth, roles, scalable, REST API | Needs JS skills; much more work |
| **Flask/Django + templates** | Classic web app | Full control, built-in auth (Django) | Slower to build UI |
| **Jupyter + ipywidgets / Voilà** | Notebook as app | Good for demos | Not suited to production use |

**Recommendation:** keep Streamlit for the prototype/demonstration. For production, put the pipeline behind a **FastAPI** service (the `services/` layer is already separated, so this is straightforward) and keep or replace the UI.

---

# 10. Suggested upgrade path

1. **Replace `PyPDF2` with `pypdf`** (deprecation).
2. **Move `facility_dictionary.pkl` → JSON** (removes the pickle risk).
3. **Add fuzzy matching** to the dictionary and verifier with `regex` or `rapidfuzz` (handles `RE Wing`, misspellings).
4. **Consider Presidio** for the regex/PHI-pattern layer, and a **clinical transformer** in place of `en_core_web_sm` to raise recall.
5. **Persist reviewer decisions** (CSV or SQLite) instead of `session_state`.
6. **Pre-process images with OpenCV** before Tesseract for the scanned batch.
7. **Move the audit log to SQLite/Postgres** and add user login.
8. Add `@st.fragment` or lazy tabs so unused tabs don't re-run.
