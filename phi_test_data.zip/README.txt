SYNTHETIC TEST DATA - PHI De-Identification Project
=====================================================
All data below is 100% fictional / machine-generated. No real patient
information is included. Built for testing the redaction pipeline.

CONTENTS
--------
handwritten_notes/        4 scanned-style handwritten clinical notes (.jpg)
                           - Each includes a deliberate OCR-style artifact
                             (a split first name, e.g. "Alli son Hill",
                             and an O/0 swap in the MRN) to exercise your
                             OCR-correction stage.

pdf_notes/                 4 typed clinical-note PDFs (.pdf)
                           - Clean, natively-typed records (is_scanned=False)
                             to test the non-OCR path.

sample_notes.csv           All 12 records in one CSV, columns:
                           note_id, patient_name, mrn, dob, phone, email,
                           facility, is_scanned, note_text
                           - Matches your existing DATASET_PATH schema
                             exactly, so it can be dropped straight into
                             the Batch tab.

sample_notes.xlsx          Same 12 records as an Excel workbook.

records.json                Raw source data (all 12 records) in case you
                           want to regenerate or tweak anything.

NOTES ON THE DATA
-----------------
- Dates are deliberately written in different formats across records
  (MM/DD/YYYY, M-D-YY, long form) to exercise date normalization.
- Facility names use your existing dictionary entries (Riverside East
  Wing, Comm. Health annex, Riverside Regional, ED Triage Unit, RE Wing).
- Phone numbers include a mix of formats (dashes, dots, extensions).
- Every record includes name, MRN, DOB, phone, email and facility, so
  you can fill in the sidebar's Verification Metadata fields and get a
  real PASS/FAIL from the Verifier on each one.
